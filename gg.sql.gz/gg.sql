-- MySQL dump 10.13  Distrib 5.7.43, for Linux (x86_64)
--
-- Host: localhost    Database: lamp
-- ------------------------------------------------------
-- Server version	5.7.43

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `about`
--

DROP TABLE IF EXISTS `about`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `about` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` longtext COLLATE utf8mb4_unicode_ci,
  `priority` int(11) DEFAULT NULL,
  `is_published` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `about`
--

LOCK TABLES `about` WRITE;
/*!40000 ALTER TABLE `about` DISABLE KEYS */;
INSERT INTO `about` VALUES (1,'Sobre nosotros','<h1>esta es nuestra historia</h1><div><strong>Ubicacion</strong> resistencia chaco <strong>origen</strong> tratamos de movernos y poder trabajar a nivel <em>nacional e internacional</em> esta es nuestra historia, somos una pequena empresa que arranco en resistencia chaco y tratamos de movernos y poder trabajar a nivel nacional e internacional esta es nuestra historia, somos una pequena empresa que arranco en resistencia chaco y tratamos de movernos y poder trabajar a nivel nacional e internacional.</div>',6,1),(2,'djdjddjdj','<div>djdjdjdj</div>',2,1);
/*!40000 ALTER TABLE `about` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `address`
--

DROP TABLE IF EXISTS `address`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `address` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `firstname` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lastname` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `company` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `postal` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `city` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `country` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_D4E6F81A76ED395` (`user_id`),
  CONSTRAINT `FK_D4E6F81A76ED395` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `address`
--

LOCK TABLES `address` WRITE;
/*!40000 ALTER TABLE `address` DISABLE KEYS */;
INSERT INTO `address` VALUES (1,3,'casa','anto','MACIEL',NULL,'camino san javier 2968','3500','resistencia','AR','3624205620');
/*!40000 ALTER TABLE `address` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bundle`
--

DROP TABLE IF EXISTS `bundle`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bundle` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `top_right_badge` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `countdown_title` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `countdown_description` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `countdown_hours` int(11) DEFAULT NULL,
  `is_promo_active` tinyint(1) NOT NULL,
  `countdown_ends_at` datetime DEFAULT NULL COMMENT '(DC2Type:datetime_immutable)',
  `discount_percentage` int(11) DEFAULT NULL,
  `is_banner_active` tinyint(1) NOT NULL,
  `banner_text` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `banner_color` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bundle`
--

LOCK TABLES `bundle` WRITE;
/*!40000 ALTER TABLE `bundle` DISABLE KEYS */;
INSERT INTO `bundle` VALUES (1,'SORPRISE','oferta_sorpresa','mas_vendido','Descuentos Fugaces!','Oferta por tiempo limitado! no te lo podes perder!!!',12,1,'2026-03-20 11:03:35',NULL,1,'¡Envío GRATIS en compras superiores a $50,000!','#f0669d');
/*!40000 ALTER TABLE `bundle` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bundle_product`
--

DROP TABLE IF EXISTS `bundle_product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bundle_product` (
  `bundle_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  PRIMARY KEY (`bundle_id`,`product_id`),
  KEY `IDX_25B2BDD4F1FAD9D3` (`bundle_id`),
  KEY `IDX_25B2BDD44584665A` (`product_id`),
  CONSTRAINT `FK_25B2BDD44584665A` FOREIGN KEY (`product_id`) REFERENCES `product` (`id`) ON DELETE CASCADE,
  CONSTRAINT `FK_25B2BDD4F1FAD9D3` FOREIGN KEY (`bundle_id`) REFERENCES `bundle` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bundle_product`
--

LOCK TABLES `bundle_product` WRITE;
/*!40000 ALTER TABLE `bundle_product` DISABLE KEYS */;
INSERT INTO `bundle_product` VALUES (1,1);
/*!40000 ALTER TABLE `bundle_product` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `carrier`
--

DROP TABLE IF EXISTS `carrier`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `carrier` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` double DEFAULT NULL,
  `type` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `carrier`
--

LOCK TABLES `carrier` WRITE;
/*!40000 ALTER TABLE `carrier` DISABLE KEYS */;
INSERT INTO `carrier` VALUES (2,'Correo Argentino','transporte Correo Argentino',0,'long_distance'),(4,'envio ejemplo','retirar en sucursal gratis',200000,'standard'),(6,'transportista OCA','OCA ENVIOS',NULL,'long_distance');
/*!40000 ALTER TABLE `carrier` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cash_movement`
--

DROP TABLE IF EXISTS `cash_movement`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cash_movement` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `reason` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `amount` double NOT NULL,
  `date` datetime NOT NULL,
  `order_reference` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cash_movement`
--

LOCK TABLES `cash_movement` WRITE;
/*!40000 ALTER TABLE `cash_movement` DISABLE KEYS */;
INSERT INTO `cash_movement` VALUES (1,'ingreso','venta',50000000,'2026-03-19 21:43:45','20260319214238-69bc6dceee3f9'),(2,'egreso','compra mercadería',100000,'2026-03-19 21:44:33',NULL),(3,'egreso','retiro',900000,'2026-03-19 22:07:55',NULL),(4,'ingreso','venta',100,'2026-03-19 23:05:41','20260319230501-69bc811dd6c94'),(5,'ingreso','venta',500000,'2026-03-19 23:07:58','20260319230743-69bc81bf90068'),(6,'ingreso','venta',100,'2026-03-19 23:09:00','20260319230845-69bc81fd87857'),(7,'ingreso','venta',100,'2026-03-19 23:10:06','20260319230953-69bc824178c3b'),(8,'ingreso','venta',100,'2026-03-23 17:58:46','20260323175744-69c17f18e6079'),(9,'ingreso','venta',500000,'2026-03-23 18:01:20','20260323180101-69c17fdd8b683'),(10,'ingreso','venta',500000,'2026-03-23 18:02:43','20260323180219-69c1802be1558'),(11,'ingreso','venta',150000,'2026-03-23 18:49:24','20260323184612-69c18a744c92e');
/*!40000 ALTER TABLE `cash_movement` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `category`
--

DROP TABLE IF EXISTS `category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `category`
--

LOCK TABLES `category` WRITE;
/*!40000 ALTER TABLE `category` DISABLE KEYS */;
INSERT INTO `category` VALUES (1,'Pulseras'),(2,'Anillos'),(3,'Collares'),(4,'Combo');
/*!40000 ALTER TABLE `category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `doctrine_migration_versions`
--

DROP TABLE IF EXISTS `doctrine_migration_versions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `doctrine_migration_versions` (
  `version` varchar(191) COLLATE utf8_unicode_ci NOT NULL,
  `executed_at` datetime DEFAULT NULL,
  `execution_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `doctrine_migration_versions`
--

LOCK TABLES `doctrine_migration_versions` WRITE;
/*!40000 ALTER TABLE `doctrine_migration_versions` DISABLE KEYS */;
INSERT INTO `doctrine_migration_versions` VALUES ('DoctrineMigrations\\Version20220216090224','2026-02-04 02:40:00',19),('DoctrineMigrations\\Version20220216094827','2026-02-04 02:40:00',21),('DoctrineMigrations\\Version20220218171218','2026-02-04 02:40:00',17),('DoctrineMigrations\\Version20220219105301','2026-02-04 02:40:00',69),('DoctrineMigrations\\Version20220220215719','2026-02-04 02:40:00',65),('DoctrineMigrations\\Version20220222211707','2026-02-04 02:40:00',21),('DoctrineMigrations\\Version20220226160703','2026-02-04 02:40:00',130),('DoctrineMigrations\\Version20220227163839','2026-02-04 02:40:00',28),('DoctrineMigrations\\Version20220227195406','2026-02-04 02:40:00',64),('DoctrineMigrations\\Version20220320164349','2026-02-04 02:40:00',27),('DoctrineMigrations\\Version20220321141846','2026-02-04 02:40:01',26),('DoctrineMigrations\\Version20220329100058','2026-02-04 02:40:01',25),('DoctrineMigrations\\Version20220401085112','2026-02-04 02:40:01',28),('DoctrineMigrations\\Version20220401092032','2026-02-04 02:40:01',18),('DoctrineMigrations\\Version20260204165437','2026-02-04 16:54:41',23),('DoctrineMigrations\\Version20260223123318','2026-02-23 12:33:31',54),('DoctrineMigrations\\Version20260225171501','2026-02-25 17:15:28',16),('DoctrineMigrations\\Version20260225172507','2026-02-25 17:25:08',16),('DoctrineMigrations\\Version20260225173730','2026-02-25 17:37:30',19),('DoctrineMigrations\\Version20260303030438','2026-03-03 03:04:39',59),('DoctrineMigrations\\Version20260303211801','2026-03-03 21:18:11',112),('DoctrineMigrations\\Version20260303213245','2026-03-03 21:33:06',51),('DoctrineMigrations\\Version20260303215011','2026-03-03 21:50:19',53),('DoctrineMigrations\\Version20260303215533','2026-03-03 21:56:29',32),('DoctrineMigrations\\Version20260303221332','2026-03-03 22:13:41',45),('DoctrineMigrations\\Version20260304005047','2026-03-04 00:51:07',51),('DoctrineMigrations\\Version20260304030547','2026-03-04 03:05:48',65),('DoctrineMigrations\\Version20260305215433','2026-03-05 21:54:33',61),('DoctrineMigrations\\Version20260305222146','2026-03-05 22:21:47',64),('DoctrineMigrations\\Version20260305230540','2026-03-05 23:05:40',53),('DoctrineMigrations\\Version20260307040314','2026-03-07 04:03:14',60),('DoctrineMigrations\\Version20260307042308','2026-03-07 04:23:08',65),('DoctrineMigrations\\Version20260307043407','2026-03-07 04:34:07',54),('DoctrineMigrations\\Version20260309192212','2026-03-09 19:22:17',130),('DoctrineMigrations\\Version20260316195227','2026-03-16 19:52:28',64),('DoctrineMigrations\\Version20260317062500','2026-03-19 21:36:55',58),('DoctrineMigrations\\Version20260319213659','2026-03-19 21:37:04',18),('DoctrineMigrations\\Version20260319213755','2026-03-19 21:37:56',20);
/*!40000 ALTER TABLE `doctrine_migration_versions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `faq`
--

DROP TABLE IF EXISTS `faq`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `faq` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `question` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `answer` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_published` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `faq`
--

LOCK TABLES `faq` WRITE;
/*!40000 ALTER TABLE `faq` DISABLE KEYS */;
INSERT INTO `faq` VALUES (1,'Donde estan ubicados?','<div>Nos ubicamos en la ciudad de Resistencia, provincia del Chaco, Argentina.</div>',1),(2,'Donde compro?','<div>Puedes visitar nuestra tienda fisica o bien realizar tu pedido y esperarlo en la puerta de tu casa en las proximas 24/48hs.</div>',1);
/*!40000 ALTER TABLE `faq` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `headers`
--

DROP TABLE IF EXISTS `headers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `headers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `content` longtext COLLATE utf8mb4_unicode_ci,
  `btn_title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `btn_url` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `headers`
--

LOCK TABLES `headers` WRITE;
/*!40000 ALTER TABLE `headers` DISABLE KEYS */;
INSERT INTO `headers` VALUES (1,NULL,NULL,NULL,'https://web.whatsapp.com/','5f6f549eefece02c0438b81e9092649f8c883bff.png'),(2,'BENDITERAS','hagan su compra por whatsapp! ❤️','Comprar ❤️','https://web.whatsapp.com/','30e73fc12a7b45268c8f073316c1d6495ffe3994.png');
/*!40000 ALTER TABLE `headers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order`
--

DROP TABLE IF EXISTS `order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `order` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL,
  `carrier_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `carrier_price` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `delivery` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `reference` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `stripe_session` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `state` int(11) NOT NULL,
  `payment_method` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_read` tinyint(1) NOT NULL,
  `gross_profit` double DEFAULT NULL,
  `receipt_filename` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_F5299398A76ED395` (`user_id`),
  CONSTRAINT `FK_F5299398A76ED395` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=302 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order`
--

LOCK TABLES `order` WRITE;
/*!40000 ALTER TABLE `order` DISABLE KEYS */;
INSERT INTO `order` VALUES (1,3,'2026-02-24 22:29:19','motomandado','1000','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260224222919-699e263fdbf36',NULL,0,NULL,1,NULL,NULL),(2,3,'2026-02-24 22:30:42','motomandado','1000','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260224223042-699e2692cd434',NULL,0,NULL,1,NULL,NULL),(3,3,'2026-02-24 22:31:24','motomandado','1000','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260224223124-699e26bc1ae88',NULL,0,NULL,1,NULL,NULL),(4,3,'2026-02-24 22:31:39','motomandado','1000','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260224223139-699e26cb35a1f','cs_test_b1roGaXvQa0f5JUzrh5Y7YbZTd6FJf5XPEPxS7lYkyOrqdi45mbRTz9T0H',0,NULL,1,NULL,NULL),(5,3,'2026-02-24 22:35:13','motomandado','1000','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260224223513-699e27a1220a3',NULL,0,NULL,1,NULL,NULL),(6,3,'2026-02-24 22:36:36','motomandado','1000','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260224223636-699e27f401e8b',NULL,0,NULL,1,NULL,NULL),(7,3,'2026-02-24 22:36:47','motomandado','1000','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260224223647-699e27ffeaf96',NULL,0,NULL,1,NULL,NULL),(8,3,'2026-02-24 22:37:15','motomandado','1000','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260224223715-699e281b8900c','cs_test_b1RSlA5zFebTgct3qzUS8thWDvpGPvFOM9ORXIxa6HxDxiyBFf8uaa0XRY',0,NULL,1,NULL,NULL),(9,3,'2026-02-24 22:41:56','motomandado','1000','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260224224156-699e293458868',NULL,1,NULL,1,NULL,NULL),(10,3,'2026-02-25 15:57:54','motomandado','1000','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260225155754-699f1c02b6427',NULL,0,NULL,1,NULL,NULL),(11,3,'2026-02-25 15:58:03','motomandado','1000','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260225155803-699f1c0bd7271',NULL,0,NULL,1,NULL,NULL),(12,3,'2026-02-25 15:58:12','motomandado','1000','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260225155812-699f1c142ebe8',NULL,0,NULL,1,NULL,NULL),(13,3,'2026-02-25 16:01:36','motomandado','1000','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260225160136-699f1ce072ce2',NULL,0,NULL,1,NULL,NULL),(14,3,'2026-02-25 16:05:10','motomandado','1000','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260225160510-699f1db607a3b',NULL,0,NULL,1,NULL,NULL),(15,3,'2026-02-25 16:12:28','motomandado','1000','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260225161228-699f1f6ce00b7','3227173728-c90445cc-9eb3-424b-89a0-5bf7fb3f49ab',0,NULL,1,NULL,NULL),(16,3,'2026-02-25 16:15:50','motomandado','1000','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260225161550-699f20367ef6f','3227173728-89996e24-8f1f-4a92-a4b0-6432c784a38d',0,NULL,1,NULL,NULL),(17,3,'2026-02-25 16:20:08','motomandado','1000','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260225162008-699f213808bf0','3227173728-5d820f90-54cc-4b8a-8a01-ed9a9803f3aa',0,NULL,1,NULL,NULL),(18,3,'2026-02-25 18:25:05','motomandado','20000','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260225182505-699f3e816afd5','3227173728-a1bef502-5b21-45f0-82ce-f4cd663e1b16',0,NULL,1,NULL,NULL),(19,3,'2026-02-25 23:13:42','motomandado','20000','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260225231342-699f82267adfb','3227173728-9886e3c2-d18d-4ad6-8e04-8d0cc11290ee',0,NULL,1,NULL,NULL),(20,3,'2026-02-27 16:12:08','motomandado','20000','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260227161208-69a1c258801e5','3227173728-319beb44-33dc-46e7-99a9-8dd36fa08369',0,NULL,1,NULL,NULL),(21,3,'2026-03-03 18:45:11','Correo Argentino','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260303184511-69a72c374a556',NULL,0,NULL,1,NULL,NULL),(22,3,'2026-03-03 18:55:08','Correo Argentino','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260303185508-69a72e8c441e6',NULL,0,NULL,1,NULL,NULL),(23,3,'2026-03-03 18:59:34','Correo Argentino','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260303185934-69a72f96490ec',NULL,1,NULL,1,NULL,NULL),(24,3,'2026-03-03 19:00:06','Correo Argentino','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260303190006-69a72fb6bb129',NULL,3,NULL,1,NULL,NULL),(25,3,'2026-03-05 20:31:46','motomandado','10000','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260305203146-69a9e832c3f09','3227173728-b4272123-cabc-43f2-b7e3-c65d886c8187',2,NULL,1,NULL,NULL),(26,3,'2026-03-05 20:47:49','motomandado','60000','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260305204749-69a9ebf5d4f2e','3227173728-3320dcf6-46d9-4afe-b528-da6c55de4596',0,NULL,1,NULL,NULL),(27,3,'2026-03-07 21:09:38','motomandado','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260307210938-69ac94123fcf1',NULL,0,NULL,1,NULL,NULL),(28,3,'2026-03-07 21:54:36','motomandado','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260307215436-69ac9e9c9d293','3227173728-c279bd3a-d29e-46ff-8c15-2b7b1c1c5921',0,NULL,1,NULL,NULL),(29,3,'2026-03-09 00:20:07','motomandado','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260309002007-69ae123750706','3227173728-10c500b2-bc62-4a57-842f-34cbc007e413',0,NULL,1,NULL,NULL),(30,3,'2026-03-09 00:22:26','motomandado','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260309002226-69ae12c236f70',NULL,0,NULL,1,NULL,NULL),(31,3,'2026-03-09 00:22:41','motomandado','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260309002241-69ae12d15f770',NULL,0,NULL,1,NULL,NULL),(32,3,'2026-03-09 00:25:02','motomandado','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260309002502-69ae135e478d9',NULL,0,NULL,1,NULL,NULL),(33,3,'2026-03-09 00:26:31','motomandado','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260309002631-69ae13b70ecfa',NULL,4,NULL,1,NULL,NULL),(34,3,'2026-03-09 17:36:13','oca','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260309173613-69af050d1fcf0',NULL,0,NULL,1,NULL,NULL),(35,3,'2026-03-09 17:36:54','oca','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260309173654-69af05362d4a6',NULL,0,NULL,1,NULL,NULL),(36,3,'2026-03-09 17:37:12','oca','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260309173712-69af0548ac216',NULL,0,NULL,1,NULL,NULL),(37,3,'2026-03-09 17:37:32','oca','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260309173732-69af055c8282c',NULL,4,NULL,1,NULL,NULL),(38,3,'2026-03-09 17:39:20','motomandado','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260309173920-69af05c83233f',NULL,0,NULL,1,NULL,NULL),(39,3,'2026-03-09 17:40:26','motomandado','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260309174026-69af060a71107',NULL,0,NULL,1,NULL,NULL),(40,3,'2026-03-09 17:40:55','motomandado','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260309174055-69af06274a567',NULL,0,NULL,1,NULL,NULL),(41,3,'2026-03-09 17:41:16','motomandado','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260309174116-69af063cb7f52',NULL,0,NULL,1,NULL,NULL),(42,3,'2026-03-09 17:41:49','motomandado','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260309174149-69af065d03158',NULL,0,NULL,1,NULL,NULL),(43,3,'2026-03-09 17:42:03','motomandado','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260309174203-69af066b27477',NULL,0,NULL,1,NULL,NULL),(44,3,'2026-03-09 17:42:19','motomandado','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260309174219-69af067b63e5f',NULL,0,NULL,1,NULL,NULL),(45,3,'2026-03-09 17:42:40','motomandado','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260309174240-69af06901997a',NULL,0,NULL,1,NULL,NULL),(46,3,'2026-03-09 17:43:00','motomandado','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260309174300-69af06a439733',NULL,0,NULL,1,NULL,NULL),(47,3,'2026-03-09 17:46:10','motomandado','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260309174610-69af07621a597',NULL,0,NULL,1,NULL,NULL),(48,3,'2026-03-09 17:48:00','motomandado','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260309174800-69af07d0e6c99',NULL,0,NULL,1,NULL,NULL),(49,3,'2026-03-09 17:48:12','motomandado','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260309174812-69af07dcdbece',NULL,0,NULL,1,NULL,NULL),(50,3,'2026-03-09 17:49:03','motomandado','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260309174903-69af080f733a7',NULL,0,NULL,1,NULL,NULL),(51,3,'2026-03-09 17:49:44','motomandado','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260309174944-69af0838f129f',NULL,0,NULL,1,NULL,NULL),(52,3,'2026-03-09 17:50:40','motomandado','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260309175040-69af08706ddce',NULL,0,NULL,1,NULL,NULL),(53,3,'2026-03-09 17:52:52','motomandado','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260309175252-69af08f4eb65a',NULL,0,NULL,1,NULL,NULL),(54,3,'2026-03-09 17:53:07','motomandado','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260309175307-69af0903af645',NULL,0,NULL,1,NULL,NULL),(55,3,'2026-03-09 17:53:32','motomandado','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260309175332-69af091c5d522',NULL,0,NULL,1,NULL,NULL),(56,3,'2026-03-09 17:53:48','motomandado','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260309175348-69af092cd90f3',NULL,0,NULL,1,NULL,NULL),(57,3,'2026-03-09 17:54:05','motomandado','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260309175405-69af093d60c1f',NULL,0,NULL,1,NULL,NULL),(58,3,'2026-03-09 17:54:42','motomandado','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260309175442-69af096266080',NULL,0,NULL,1,NULL,NULL),(59,3,'2026-03-09 18:14:41','motomandado','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260309181441-69af0e11467ac',NULL,0,NULL,1,NULL,NULL),(60,3,'2026-03-09 18:30:01','motomandado','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260309183001-69af11a996529',NULL,0,NULL,1,NULL,NULL),(61,3,'2026-03-09 18:30:40','motomandado','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260309183040-69af11d025b49',NULL,0,NULL,1,NULL,NULL),(62,3,'2026-03-09 18:31:13','motomandado','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260309183113-69af11f13c70f',NULL,0,NULL,1,NULL,NULL),(63,3,'2026-03-09 18:31:37','motomandado','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260309183137-69af1209a48bb',NULL,0,NULL,1,NULL,NULL),(64,3,'2026-03-09 02:46:29','motomandado','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260310024629-69af860551a4f',NULL,4,'cash',1,NULL,NULL),(65,3,'2026-03-10 15:54:43','motomandado','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260310155443-69b03ec39498d',NULL,0,NULL,1,NULL,NULL),(66,3,'2026-03-10 15:59:28','motomandado','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260310155928-69b03fe0d412b',NULL,0,NULL,1,NULL,NULL),(67,3,'2026-03-10 16:08:17','Pendiente de selección','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260310160817-69b041f136793',NULL,0,NULL,1,NULL,NULL),(68,3,'2026-03-10 16:11:21','Pendiente de selección','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260310161121-69b042a96061b',NULL,0,NULL,1,NULL,NULL),(69,3,'2026-03-10 16:11:25','Pendiente de selección','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260310161125-69b042ad5e49c',NULL,0,NULL,1,NULL,NULL),(70,3,'2026-03-10 16:13:57','Pendiente de selección','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260310161357-69b04345663b4',NULL,0,NULL,1,NULL,NULL),(71,3,'2026-03-10 16:17:07','Pendiente de selección','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260310161707-69b04403dced4',NULL,0,NULL,1,NULL,NULL),(72,3,'2026-03-10 16:17:14','Pendiente de selección','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260310161714-69b0440a5e83e',NULL,0,NULL,1,NULL,NULL),(73,3,'2026-03-10 16:21:03','Pendiente de selección','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260310162103-69b044efeae25',NULL,0,NULL,1,NULL,NULL),(74,3,'2026-03-10 16:22:21','Pendiente de selección','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260310162221-69b0453d0596d',NULL,0,NULL,1,NULL,NULL),(75,3,'2026-03-10 16:22:42','Pendiente de selección','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260310162242-69b0455265b18',NULL,0,NULL,1,NULL,NULL),(76,3,'2026-03-10 16:22:50','Pendiente de selección','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260310162250-69b0455a09e2d',NULL,0,NULL,1,NULL,NULL),(77,3,'2026-03-10 16:23:06','Pendiente de selección','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260310162306-69b0456ace795',NULL,0,NULL,1,NULL,NULL),(78,3,'2026-03-10 16:23:37','Pendiente de selección','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260310162337-69b04589a795d',NULL,0,NULL,1,NULL,NULL),(79,3,'2026-03-10 16:25:53','Pendiente de selección','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260310162553-69b04611adcca',NULL,0,NULL,1,NULL,NULL),(80,3,'2026-03-10 16:26:59','Pendiente de selección','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260310162659-69b04653265dd',NULL,0,NULL,1,NULL,NULL),(81,3,'2026-03-10 16:28:29','Pendiente de selección','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260310162829-69b046ade01fb',NULL,0,NULL,1,NULL,NULL),(82,3,'2026-03-10 16:32:09','Pendiente de selección','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260310163209-69b047895608a',NULL,0,NULL,1,NULL,NULL),(83,3,'2026-03-10 16:35:19','Pendiente de selección','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260310163519-69b048476ca5c',NULL,0,NULL,1,NULL,NULL),(84,3,'2026-03-10 16:37:17','Pendiente de selección','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260310163717-69b048bdadaa2',NULL,0,NULL,1,NULL,NULL),(85,3,'2026-03-10 16:38:58','Pendiente de selección','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260310163858-69b04922e83f8',NULL,0,NULL,1,NULL,NULL),(86,3,'2026-03-10 16:39:06','Pendiente de selección','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260310163906-69b0492a52a6b',NULL,0,NULL,1,NULL,NULL),(87,3,'2026-03-10 16:41:27','Pendiente de selección','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260310164127-69b049b741901',NULL,0,NULL,1,NULL,NULL),(88,3,'2026-03-10 16:41:41','Pendiente de selección','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260310164141-69b049c51b0c8',NULL,0,NULL,1,NULL,NULL),(89,3,'2026-03-10 16:44:37','Pendiente de selección','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260310164437-69b04a759ad05',NULL,0,NULL,1,NULL,NULL),(90,3,'2026-03-10 16:46:08','Pendiente de selección','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260310164608-69b04ad069699',NULL,0,NULL,1,NULL,NULL),(91,3,'2026-03-10 16:46:21','Pendiente de selección','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260310164621-69b04adda4446',NULL,0,NULL,1,NULL,NULL),(92,3,'2026-03-10 16:49:12','Pendiente de selección','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260310164912-69b04b882b553',NULL,0,NULL,1,NULL,NULL),(93,3,'2026-03-10 16:54:21','Pendiente de selección','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260310165421-69b04cbd93aa9',NULL,0,NULL,1,NULL,NULL),(94,3,'2026-03-10 16:54:24','Pendiente de selección','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260310165424-69b04cc077255',NULL,0,NULL,1,NULL,NULL),(95,3,'2026-03-10 16:56:54','Pendiente de selección','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260310165654-69b04d5625b59',NULL,0,NULL,1,NULL,NULL),(96,3,'2026-03-10 16:58:08','Pendiente de selección','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260310165808-69b04da08cca3',NULL,0,NULL,1,NULL,NULL),(97,3,'2026-03-10 16:58:21','Pendiente de selección','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260310165821-69b04dad53f2a',NULL,0,NULL,1,NULL,NULL),(98,3,'2026-03-10 16:58:42','Pendiente de selección','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260310165842-69b04dc2e7cef',NULL,0,NULL,1,NULL,NULL),(99,3,'2026-03-10 17:25:30','Pendiente de selección','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260310172530-69b0540a7cc95',NULL,0,NULL,1,NULL,NULL),(100,3,'2026-03-10 18:04:26','Pendiente de selección','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260310180426-69b05d2a3de76',NULL,0,NULL,1,NULL,NULL),(101,3,'2026-03-10 18:05:30','Pendiente de selección','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260310180530-69b05d6a8d53a',NULL,0,NULL,1,NULL,NULL),(102,3,'2026-03-10 18:06:10','Pendiente de selección','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260310180610-69b05d92c2cbc',NULL,0,NULL,1,NULL,NULL),(103,3,'2026-03-10 18:07:07','Pendiente de selección','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260310180707-69b05dcb7c2f1',NULL,0,NULL,1,NULL,NULL),(104,3,'2026-03-10 18:09:23','Pendiente de selección','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260310180923-69b05e538d8d8',NULL,0,NULL,1,NULL,NULL),(105,3,'2026-03-10 18:10:57','Pendiente de selección','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260310181057-69b05eb1d151a',NULL,0,NULL,1,NULL,NULL),(106,3,'2026-03-10 18:11:08','Pendiente de selección','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260310181108-69b05ebca9269',NULL,0,NULL,1,NULL,NULL),(107,3,'2026-03-10 18:21:29','Pendiente de selección','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260310182129-69b061292d796',NULL,0,NULL,1,NULL,NULL),(108,3,'2026-03-10 18:26:05','Pendiente de selección','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260310182605-69b0623dbf473',NULL,0,NULL,1,NULL,NULL),(109,3,'2026-03-10 18:27:21','Pendiente de selección','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260310182721-69b0628915be1',NULL,0,NULL,1,NULL,NULL),(110,3,'2026-03-10 18:30:43','Pendiente de selección','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260310183043-69b0635341111',NULL,0,NULL,1,NULL,NULL),(111,3,'2026-03-10 18:50:00','Pendiente de selección','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260310185000-69b067d85fe24',NULL,0,NULL,1,NULL,NULL),(112,3,'2026-03-11 17:53:27','Pendiente de selección','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260311175327-69b1ac17c79f8',NULL,0,NULL,1,NULL,NULL),(113,3,'2026-03-13 18:46:47','Pendiente de selección','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260313184647-69b45b9790a02',NULL,0,NULL,1,NULL,NULL),(114,3,'2026-03-13 19:35:18','Pendiente de selección','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260313193518-69b466f663fc5',NULL,0,NULL,1,NULL,NULL),(115,3,'2026-03-13 20:09:35','motomandado','80000','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260313200935-69b46eff7dfbe',NULL,0,NULL,1,NULL,NULL),(116,3,'2026-03-13 20:09:56','motomandado','80000','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260313200956-69b46f14629d5','3227173728-020f79e8-1874-4f12-89fa-4d496626bb01',0,'mercadopago',1,NULL,NULL),(117,3,'2026-03-13 20:12:56','Pendiente de selección','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260313201256-69b46fc8d3066',NULL,0,NULL,1,NULL,NULL),(118,3,'2026-03-13 20:16:03','Pendiente de selección','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260313201603-69b47083e21d3',NULL,0,NULL,1,NULL,NULL),(119,3,'2026-03-13 20:25:06','Pendiente de selección','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260313202506-69b472a2ce7d8',NULL,4,'cash',1,NULL,NULL),(120,3,'2026-03-13 20:55:05','Pendiente de selección','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260313205505-69b479a976be9',NULL,4,'cash',1,NULL,NULL),(121,3,'2026-03-13 20:57:00','Pendiente de selección','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260313205700-69b47a1c3360d',NULL,4,'cash',1,NULL,NULL),(122,3,'2026-03-13 20:57:57','motomandado','80000','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260313205757-69b47a55bbda1',NULL,0,NULL,1,NULL,NULL),(123,3,'2026-03-15 01:07:18','Pendiente de selección','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260315010718-69b60646b0293',NULL,0,NULL,1,NULL,NULL),(124,3,'2026-03-15 01:07:46','Pendiente de selección','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260315010746-69b60662d606b',NULL,0,NULL,1,NULL,NULL),(125,3,'2026-03-15 01:08:16','Pendiente de selección','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260315010816-69b6068065993',NULL,0,NULL,1,NULL,NULL),(126,3,'2026-03-15 01:08:27','Pendiente de selección','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260315010827-69b6068b7fad5',NULL,0,NULL,1,NULL,NULL),(127,3,'2026-03-15 01:08:39','Pendiente de selección','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260315010839-69b6069730559',NULL,0,NULL,1,NULL,NULL),(128,3,'2026-03-15 01:08:55','Pendiente de selección','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260315010855-69b606a70902b',NULL,0,NULL,1,NULL,NULL),(129,3,'2026-03-15 01:10:02','Pendiente de selección','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260315011002-69b606eadb34d',NULL,0,NULL,1,NULL,NULL),(130,3,'2026-03-15 01:10:32','Pendiente de selección','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260315011032-69b60708293ff',NULL,0,NULL,1,NULL,NULL),(131,3,'2026-03-15 01:10:48','Pendiente de selección','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260315011048-69b60718a1d38',NULL,0,NULL,1,NULL,NULL),(132,3,'2026-03-15 01:11:10','motomandado','80000','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260315011110-69b6072edb3dc',NULL,0,NULL,1,NULL,NULL),(133,3,'2026-03-15 01:31:14','motomandado','80000','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260315013114-69b60be254a49','3227173728-2069d509-cdfe-47e8-907e-7e271756b766',0,'mercadopago',1,NULL,NULL),(134,3,'2026-03-16 18:40:38','Pendiente de selección','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260316184038-69b84ea69d59f',NULL,0,NULL,1,NULL,NULL),(135,3,'2026-03-16 18:41:01','Pendiente de selección','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260316184101-69b84ebd42740',NULL,0,NULL,1,NULL,NULL),(136,3,'2026-03-16 18:41:42','Pendiente de selección','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260316184142-69b84ee64129c',NULL,0,NULL,1,NULL,NULL),(137,3,'2026-03-16 18:42:46','Pendiente de selección','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260316184246-69b84f26cf764',NULL,0,NULL,1,NULL,NULL),(138,3,'2026-03-16 18:42:58','Pendiente de selección','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260316184258-69b84f32527d9',NULL,0,NULL,1,NULL,NULL),(139,3,'2026-03-16 18:43:06','Pendiente de selección','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260316184306-69b84f3a83356',NULL,0,NULL,1,NULL,NULL),(140,3,'2026-03-16 18:43:32','Pendiente de selección','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260316184332-69b84f54ee8e6',NULL,0,NULL,1,NULL,NULL),(141,3,'2026-03-16 18:43:55','Pendiente de selección','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260316184355-69b84f6b86fa0',NULL,0,NULL,1,NULL,NULL),(142,3,'2026-03-16 18:44:33','Pendiente de selección','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260316184433-69b84f9197d72',NULL,0,NULL,1,NULL,NULL),(143,3,'2026-03-16 18:44:39','Pendiente de selección','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260316184439-69b84f97c96e4',NULL,0,NULL,1,NULL,NULL),(144,3,'2026-03-16 18:45:05','Pendiente de selección','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260316184505-69b84fb1be37c',NULL,0,NULL,1,NULL,NULL),(145,3,'2026-03-16 18:45:39','Pendiente de selección','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260316184539-69b84fd3ec290',NULL,0,NULL,1,NULL,NULL),(146,3,'2026-03-16 18:45:49','Pendiente de selección','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260316184549-69b84fddc3dbf',NULL,0,NULL,1,NULL,NULL),(147,3,'2026-03-16 18:47:58','Pendiente de selección','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260316184758-69b8505e81003',NULL,0,NULL,1,NULL,NULL),(148,3,'2026-03-16 18:48:10','Pendiente de selección','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260316184810-69b8506aa6d97',NULL,0,NULL,1,NULL,NULL),(149,3,'2026-03-16 18:48:47','Pendiente de selección','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260316184847-69b8508f04674',NULL,0,NULL,1,NULL,NULL),(150,3,'2026-03-16 18:49:23','Pendiente de selección','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260316184923-69b850b3eaaf0',NULL,0,NULL,1,NULL,NULL),(151,3,'2026-03-16 18:50:07','Pendiente de selección','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260316185007-69b850dfd19f4',NULL,0,NULL,1,NULL,NULL),(152,3,'2026-03-16 18:50:25','Pendiente de selección','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260316185025-69b850f12b7a5',NULL,0,NULL,1,NULL,NULL),(153,3,'2026-03-16 18:50:31','Pendiente de selección','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260316185031-69b850f7efe0e',NULL,0,NULL,1,NULL,NULL),(154,3,'2026-03-16 18:50:45','Pendiente de selección','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260316185045-69b851054e640',NULL,0,NULL,1,NULL,NULL),(155,3,'2026-03-16 18:51:07','Pendiente de selección','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260316185107-69b8511b018b8',NULL,0,NULL,1,NULL,NULL),(156,3,'2026-03-16 18:51:28','Pendiente de selección','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260316185128-69b8513023caa',NULL,0,NULL,1,NULL,NULL),(157,3,'2026-03-16 18:52:21','Pendiente de selección','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260316185221-69b85165dd6be',NULL,0,NULL,1,NULL,NULL),(158,3,'2026-03-16 18:52:34','Pendiente de selección','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260316185234-69b8517282a8c',NULL,0,NULL,1,NULL,NULL),(159,3,'2026-03-16 18:52:49','Pendiente de selección','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260316185249-69b8518133b7f',NULL,0,NULL,1,NULL,NULL),(160,3,'2026-03-16 18:53:15','Pendiente de selección','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260316185315-69b8519b5017b',NULL,4,'cash',1,NULL,NULL),(161,3,'2026-03-16 18:57:22','Pendiente de selección','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260316185722-69b85292657ff',NULL,0,NULL,1,NULL,NULL),(162,3,'2026-03-16 18:57:42','Pendiente de selección','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260316185742-69b852a62f070',NULL,0,NULL,1,NULL,NULL),(163,3,'2026-03-16 19:00:45','Pendiente de selección','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260316190045-69b8535ddb6c5',NULL,0,NULL,1,NULL,NULL),(164,3,'2026-03-16 19:02:48','Pendiente de selección','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260316190248-69b853d834412',NULL,0,NULL,1,NULL,NULL),(165,3,'2026-03-16 19:03:51','Pendiente de selección','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260316190351-69b8541701b24',NULL,0,NULL,1,NULL,NULL),(166,3,'2026-03-16 19:04:27','Pendiente de selección','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260316190427-69b8543b07ad1',NULL,4,'cash',1,NULL,NULL),(167,3,'2026-03-16 19:12:13','Pendiente de selección','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260316191213-69b8560d03a96',NULL,4,'cash',1,NULL,NULL),(168,3,'2026-03-16 22:53:08','Pendiente de selección','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260316225308-69b889d44c7e3',NULL,0,NULL,1,NULL,NULL),(169,3,'2026-03-17 03:37:06','Retirar en sucursal','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260317033706-69b8cc62da75a',NULL,4,'transfer',1,NULL,NULL),(170,3,'2026-03-17 04:49:16','Pendiente de selección','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260317044916-69b8dd4ce82aa',NULL,0,NULL,1,NULL,NULL),(171,3,'2026-03-17 04:58:29','Pendiente de selección','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260317045829-69b8df75b8a5d',NULL,0,NULL,1,NULL,NULL),(172,3,'2026-03-17 04:58:49','Pendiente de selección','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260317045849-69b8df89430c1',NULL,0,NULL,1,NULL,NULL),(173,3,'2026-03-17 04:59:28','Pendiente de selección','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260317045928-69b8dfb027659',NULL,0,NULL,1,NULL,NULL),(174,3,'2026-03-17 05:00:00','Retirar en sucursal','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260317050000-69b8dfd0f1225',NULL,0,NULL,1,NULL,NULL),(175,3,'2026-03-17 05:00:43','Retirar en sucursal','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260317050043-69b8dffb76f3f',NULL,0,NULL,1,NULL,NULL),(176,3,'2026-03-17 05:01:16','Pendiente de selección','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260317050116-69b8e01c780dd',NULL,0,NULL,1,NULL,NULL),(177,3,'2026-03-17 05:05:26','Pendiente de selección','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260317050526-69b8e116f0b29',NULL,0,NULL,1,NULL,NULL),(178,3,'2026-03-17 05:05:57','Retirar en sucursal','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260317050557-69b8e1350f1e6',NULL,4,'cash',1,NULL,NULL),(179,3,'2026-03-17 05:07:27','Retirar en sucursal','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260317050727-69b8e18fc337c',NULL,0,'cash',1,NULL,NULL),(180,3,'2026-03-18 00:57:10','Pendiente de selección','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260318005710-69b9f8667930a',NULL,0,NULL,1,NULL,NULL),(181,3,'2026-03-19 01:39:55','Pendiente de selección','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260319013955-69bb53ebdfa4d',NULL,0,NULL,1,NULL,NULL),(182,3,'2026-03-19 02:38:41','Pendiente de selección','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260319023841-69bb61b1e70a6',NULL,0,NULL,1,NULL,NULL),(183,3,'2026-03-19 02:43:20','Pendiente de selección','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260319024320-69bb62c84464a',NULL,0,NULL,1,NULL,NULL),(184,3,'2026-03-19 02:45:33','Pendiente de selección','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260319024533-69bb634de5660',NULL,0,NULL,1,NULL,NULL),(185,3,'2026-03-19 02:46:02','Pendiente de selección','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260319024602-69bb636a95f5d',NULL,0,NULL,1,NULL,NULL),(186,3,'2026-03-19 02:46:06','Pendiente de selección','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260319024606-69bb636e2745a',NULL,0,NULL,1,NULL,NULL),(187,3,'2026-03-19 02:48:47','Pendiente de selección','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260319024847-69bb640f35c5d',NULL,0,NULL,1,NULL,NULL),(188,3,'2026-03-19 02:50:25','Pendiente de selección','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260319025025-69bb647165ba5',NULL,0,NULL,1,NULL,NULL),(189,3,'2026-03-19 02:50:34','Pendiente de selección','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260319025034-69bb647ae44b5',NULL,0,NULL,1,NULL,NULL),(190,3,'2026-03-19 02:51:10','Pendiente de selección','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260319025110-69bb649ec04b8',NULL,0,NULL,1,NULL,NULL),(191,3,'2026-03-19 02:51:45','Pendiente de selección','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260319025145-69bb64c1bd036',NULL,0,NULL,1,NULL,NULL),(192,3,'2026-03-19 02:52:30','Pendiente de selección','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260319025230-69bb64ee7924a',NULL,0,NULL,1,NULL,NULL),(193,3,'2026-03-19 02:53:26','Pendiente de selección','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260319025326-69bb652611928',NULL,0,NULL,1,NULL,NULL),(194,3,'2026-03-19 02:54:02','Pendiente de selección','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260319025402-69bb654a4878c',NULL,0,NULL,1,NULL,NULL),(195,3,'2026-03-19 02:54:14','Pendiente de selección','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260319025414-69bb655621c0f',NULL,0,NULL,1,NULL,NULL),(196,3,'2026-03-19 02:54:23','Pendiente de selección','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260319025423-69bb655fafe01',NULL,0,NULL,1,NULL,NULL),(197,3,'2026-03-19 02:54:40','Retirar en local','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260319025440-69bb65708a20d',NULL,0,NULL,1,NULL,NULL),(198,3,'2026-03-19 03:16:11','Retirar en local','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260319031611-69bb6a7b815b8',NULL,1,'cash',1,NULL,NULL),(199,3,'2026-03-19 04:20:56','Retirar en local','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260319042056-69bb79a839666',NULL,1,'cash',1,0,NULL),(200,3,'2026-03-19 04:23:24','Retirar en local','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260319042324-69bb7a3cdb268',NULL,4,'cash',1,400000,NULL),(201,3,'2026-03-19 04:26:59','Retirar en local','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260319042659-69bb7b13adf1b',NULL,4,'cash',1,800000,NULL),(202,3,'2026-03-19 04:31:58','Retirar en local','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260319043158-69bb7c3ef0015',NULL,4,'cash',1,13200000,NULL),(203,3,'2026-03-19 04:32:46','Retirar en local','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260319043246-69bb7c6eaeb81',NULL,4,'cash',1,200000,NULL),(204,3,'2026-03-19 21:42:38','Retirar en local','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260319214238-69bc6dceee3f9',NULL,1,'cash',1,50000000,NULL),(205,3,'2026-03-19 23:05:01','Retirar en local','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260319230501-69bc811dd6c94',NULL,1,'cash',1,100,NULL),(206,3,'2026-03-19 23:07:43','Retirar en local','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260319230743-69bc81bf90068',NULL,1,'cash',0,200000,NULL),(207,3,'2026-03-19 23:08:45','Retirar en local','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260319230845-69bc81fd87857',NULL,1,'cash',0,100,NULL),(208,3,'2026-03-19 23:09:53','Retirar en local','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260319230953-69bc824178c3b',NULL,1,'cash',0,100,NULL),(209,3,'2026-03-19 23:15:29','Retirar en local','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260319231529-69bc83915b3fd',NULL,4,'cash',0,200000,NULL),(210,3,'2026-03-19 23:15:59','Retirar en local','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260319231559-69bc83afbe7a6',NULL,4,'cash',0,100,NULL),(211,3,'2026-03-23 17:57:44','Retirar en local','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260323175744-69c17f18e6079',NULL,1,'cash',0,100,NULL),(212,3,'2026-03-23 18:01:01','Retirar en local','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260323180101-69c17fdd8b683',NULL,1,'cash',0,200000,NULL),(213,3,'2026-03-23 18:02:19','Retirar en local','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260323180219-69c1802be1558',NULL,1,'cash',0,200000,NULL),(214,3,'2026-03-23 18:46:12','Retirar en local','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260323184612-69c18a744c92e',NULL,1,'cash',0,150000,NULL),(215,3,'2026-03-23 22:05:00','Retirar en local','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260323220500-69c1b90c6c63a',NULL,4,'cash',1,4160000,NULL),(216,3,'2026-03-23 23:44:39','Retirar en local','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260323234439-69c1d0679fe10',NULL,4,'transfer',0,15300000,NULL),(217,3,'2026-03-24 01:01:30','Retirar en local','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260324010130-69c1e26a67cd5',NULL,0,NULL,0,2700000,NULL),(218,3,'2026-03-24 01:04:35','Retirar en local','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260324010435-69c1e323e5672',NULL,0,NULL,0,2700000,NULL),(219,3,'2026-03-24 01:05:58','Retirar en local','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260324010558-69c1e3762b3d3',NULL,0,NULL,0,2700000,NULL),(220,3,'2026-03-24 01:06:09','Retirar en local','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260324010609-69c1e381a1a7e',NULL,4,'cash',0,2700000,NULL),(221,3,'2026-03-24 01:06:49','Retirar en local','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260324010649-69c1e3a9abab1',NULL,4,'cash',0,3000000,NULL),(222,3,'2026-03-24 01:07:15','Retirar en local','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260324010715-69c1e3c3d6e71',NULL,4,'cash',0,3000000,NULL),(223,3,'2026-03-24 01:11:00','Retirar en local','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260324011100-69c1e4a422f1f',NULL,4,'cash',0,300000,NULL),(224,3,'2026-03-24 01:11:53','Retirar en local','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260324011153-69c1e4d97ce00',NULL,4,'cash',0,300000,NULL),(225,3,'2026-03-24 01:13:08','Retirar en local','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260324011308-69c1e52468124',NULL,4,'cash',0,300000,NULL),(226,3,'2026-03-24 01:14:00','Retirar en local','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260324011400-69c1e558ccb9c',NULL,4,'cash',0,800000,NULL),(227,3,'2026-03-24 01:15:59','Retirar en local','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260324011559-69c1e5cf30828',NULL,4,'cash',0,3000000,NULL),(228,3,'2026-03-24 01:27:56','Pendiente de selección','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260324012756-69c1e89c8bcea',NULL,0,NULL,0,0,NULL),(229,3,'2026-03-24 01:28:02','Pendiente de selección','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260324012802-69c1e8a2aadf4',NULL,0,NULL,0,0,NULL),(230,3,'2026-03-24 01:28:06','Pendiente de selección','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260324012806-69c1e8a6ac655',NULL,0,NULL,0,0,NULL),(231,3,'2026-03-24 01:30:03','Pendiente de selección','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260324013003-69c1e91bc8a8d',NULL,0,NULL,0,0,NULL),(232,3,'2026-03-24 01:30:11','Retirar en local','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260324013011-69c1e92334fa0',NULL,4,'cash',0,33000000,NULL),(233,3,'2026-03-24 01:31:07','Retirar en local','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260324013107-69c1e95b26c01',NULL,4,'cash',0,3000000,NULL),(234,3,'2026-03-24 01:31:30','Retirar en local','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260324013130-69c1e972e5f1d',NULL,4,'cash',0,3000000,NULL),(235,3,'2026-03-24 01:31:48','Retirar en local','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260324013148-69c1e984f2d98',NULL,4,'cash',0,3000000,NULL),(236,3,'2026-03-24 01:36:28','Retirar en local','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260324013628-69c1ea9c3aaf1',NULL,4,'cash',0,3000000,NULL),(237,3,'2026-03-24 01:36:54','Retirar en local','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260324013654-69c1eab6d2347',NULL,4,'cash',0,3000000,NULL),(238,3,'2026-03-24 01:39:58','Retirar en local','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260324013958-69c1eb6e51ef2',NULL,4,'cash',0,3300000,NULL),(239,3,'2026-03-24 01:42:50','Retirar en local','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260324014250-69c1ec1a3ee10',NULL,4,'cash',0,3000000,NULL),(240,3,'2026-03-24 01:43:18','Retirar en local','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260324014318-69c1ec36cb6ee',NULL,4,'cash',0,3000000,NULL),(241,3,'2026-03-24 01:44:16','Retirar en local','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260324014416-69c1ec70374bc',NULL,4,'cash',0,300000,NULL),(242,3,'2026-03-24 01:46:52','Retirar en local','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260324014652-69c1ed0cca042',NULL,4,'cash',0,900000,NULL),(243,3,'2026-03-24 01:47:41','Retirar en local','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260324014741-69c1ed3d1718b',NULL,0,NULL,0,300000,NULL),(244,3,'2026-03-24 01:48:04','Retirar en local','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260324014804-69c1ed5484cb6',NULL,4,'cash',0,300000,NULL),(245,3,'2026-03-24 01:49:16','Retirar en local','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260324014916-69c1ed9cd0efd',NULL,4,'cash',0,300000,NULL),(246,3,'2026-03-24 01:50:39','Pendiente de selección','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260324015039-69c1edef3d82d',NULL,0,NULL,0,0,NULL),(247,3,'2026-03-24 01:50:57','Pendiente de selección','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260324015057-69c1ee01cb65e',NULL,0,NULL,0,0,NULL),(248,3,'2026-03-24 01:52:42','Pendiente de selección','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260324015242-69c1ee6a55d4b',NULL,0,NULL,0,0,NULL),(249,3,'2026-03-24 01:52:46','Pendiente de selección','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260324015246-69c1ee6e86e1c',NULL,0,NULL,0,0,NULL),(250,3,'2026-03-24 01:54:31','Pendiente de selección','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260324015431-69c1eed7432a7',NULL,0,NULL,0,0,NULL),(251,3,'2026-03-24 01:55:28','Pendiente de selección','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260324015528-69c1ef10a5ff9',NULL,0,NULL,0,0,NULL),(252,3,'2026-03-24 01:55:46','Pendiente de selección','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260324015546-69c1ef226d22b',NULL,0,NULL,0,0,NULL),(253,3,'2026-03-24 01:56:30','Pendiente de selección','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260324015630-69c1ef4eeb266',NULL,0,NULL,0,0,NULL),(254,3,'2026-03-24 01:56:49','Pendiente de selección','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260324015649-69c1ef6101da2',NULL,0,NULL,1,300000,NULL),(255,3,'2026-03-24 01:57:32','Pendiente de selección','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260324015732-69c1ef8c510fa',NULL,0,NULL,0,0,NULL),(256,3,'2026-03-24 01:58:01','Pendiente de selección','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260324015801-69c1efa92d237',NULL,0,NULL,0,0,NULL),(257,3,'2026-03-24 01:58:45','Pendiente de selección','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260324015845-69c1efd51372b',NULL,0,NULL,0,0,NULL),(258,3,'2026-03-24 01:59:10','Pendiente de selección','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260324015910-69c1efeebd6fb',NULL,0,NULL,0,0,NULL),(259,3,'2026-03-24 01:59:22','Pendiente de selección','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260324015922-69c1effa4a0ac',NULL,0,NULL,0,0,NULL),(260,3,'2026-03-24 02:01:13','Pendiente de selección','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260324020113-69c1f06963d22',NULL,0,NULL,0,0,NULL),(261,3,'2026-03-24 02:03:04','Pendiente de selección','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260324020304-69c1f0d8151ad',NULL,0,NULL,0,0,NULL),(262,3,'2026-03-24 02:03:30','Pendiente de selección','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260324020330-69c1f0f26f8c1',NULL,0,NULL,0,0,NULL),(263,3,'2026-03-24 02:03:52','Pendiente de selección','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260324020352-69c1f1084cacf',NULL,0,NULL,0,0,NULL),(264,3,'2026-03-24 02:11:55','Pendiente de selección','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260324021155-69c1f2eb0c7ea',NULL,0,NULL,0,0,NULL),(265,3,'2026-03-24 02:13:25','Pendiente de selección','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260324021325-69c1f345b7d87',NULL,0,NULL,0,0,NULL),(266,3,'2026-03-24 02:13:59','Retirar en local','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260324021359-69c1f367f132a',NULL,4,'cash',0,300000,NULL),(267,3,'2026-03-24 02:16:45','Retirar en local','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260324021645-69c1f40de84ae',NULL,1,'cash',0,3000000,NULL),(268,3,'2026-03-24 02:17:48','Retirar en local','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260324021748-69c1f44c9b7f9',NULL,4,'cash',0,300000,NULL),(269,3,'2026-03-24 02:18:30','Retirar en local','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260324021830-69c1f4765a368',NULL,4,'cash',0,800000,NULL),(270,3,'2026-03-24 02:18:56','Retirar en local','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260324021856-69c1f490e86b5',NULL,4,'cash',0,300000,NULL),(271,3,'2026-03-24 02:28:48','Retirar en local','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260324022848-69c1f6e08c160',NULL,0,NULL,0,900000,NULL),(272,3,'2026-03-24 02:29:16','Retirar en local','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260324022916-69c1f6fc08ed0',NULL,0,NULL,1,900000,NULL),(273,3,'2026-03-24 02:29:59','Retirar en local','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260324022959-69c1f727ddaf0',NULL,4,'cash',0,900000,NULL),(274,3,'2026-03-24 02:31:52','Retirar en local','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260324023152-69c1f798c98f6',NULL,4,'cash',0,1600000,NULL),(275,3,'2026-03-26 01:28:04','Correo Argentino','470000','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260326012804-69c48ba42cb11',NULL,4,'transfer',0,4800000,NULL),(276,3,'2026-03-26 03:31:20','Retirar en local','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260326033120-69c4a888907ac',NULL,4,'cash',0,900000,'comprobante_20260326033120-69c4a888907ac.pdf'),(277,3,'2026-03-26 00:39:26','Retirar en local','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260326003926-69c4aa6ea20e4',NULL,4,'cash',0,6900000,'comprobante_20260326003926-69c4aa6ea20e4.pdf'),(278,3,'2026-03-26 00:46:41','Retirar en local','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260326004641-69c4ac219421b',NULL,4,'cash',0,900000,'comprobante_20260326004641-69c4ac219421b.pdf'),(279,3,'2026-03-26 02:42:46','Pendiente de selección','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260326024246-69c4c7567bc92',NULL,0,NULL,0,0,NULL),(280,3,'2026-03-26 02:43:22','Pendiente de selección','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260326024322-69c4c77a6e5a7',NULL,0,NULL,0,0,NULL),(281,3,'2026-03-26 02:43:34','Pendiente de selección','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260326024334-69c4c786c76db',NULL,0,NULL,0,0,NULL),(282,3,'2026-03-26 02:43:37','Pendiente de selección','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260326024337-69c4c7890128d',NULL,0,NULL,0,0,NULL),(283,3,'2026-03-26 02:43:38','Pendiente de selección','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260326024338-69c4c78a6dfaa',NULL,0,NULL,0,0,NULL),(284,3,'2026-03-26 02:43:44','Pendiente de selección','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260326024344-69c4c7905d5d6',NULL,0,NULL,0,0,NULL),(285,3,'2026-03-26 02:43:48','Retirar en local','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260326024348-69c4c7947413d',NULL,0,NULL,0,8700000,NULL),(286,3,'2026-03-26 02:44:35','Retirar en local','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260326024435-69c4c7c306b87',NULL,0,NULL,0,8700000,NULL),(287,3,'2026-03-26 02:44:38','Pendiente de selección','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260326024438-69c4c7c686e16',NULL,0,NULL,0,0,NULL),(288,3,'2026-03-26 02:44:43','Retirar en local','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260326024443-69c4c7cb5da1b',NULL,0,NULL,0,8700000,NULL),(289,3,'2026-03-26 02:55:48','Retirar en local','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260326025548-69c4ca64dfada',NULL,0,NULL,0,12610000,NULL),(290,3,'2026-03-26 02:58:54','Retirar en local','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260326025854-69c4cb1e59769',NULL,4,'cash',0,12610000,'comprobante_20260326025854-69c4cb1e59769.pdf'),(291,3,'2026-03-26 03:00:41','Retirar en local','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260326030041-69c4cb89c0adc',NULL,4,'cash',0,60000,'comprobante_20260326030041-69c4cb89c0adc.pdf'),(292,3,'2026-03-26 03:03:07','Retirar en local','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260326030307-69c4cc1b6f25d',NULL,0,NULL,0,3000000,NULL),(293,3,'2026-03-26 03:03:15','Retirar en local','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260326030315-69c4cc2338bbb',NULL,4,'cash',0,3000000,'comprobante_20260326030315-69c4cc2338bbb.pdf'),(294,3,'2026-03-26 03:04:26','Retirar en local','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260326030426-69c4cc6aa8903',NULL,4,'cash',0,300000,'comprobante_20260326030426-69c4cc6aa8903.pdf'),(295,3,'2026-03-26 03:04:46','Retirar en local','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260326030446-69c4cc7e552d5',NULL,4,'cash',0,300000,'comprobante_20260326030446-69c4cc7e552d5.pdf'),(296,3,'2026-03-26 03:05:33','Retirar en local','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260326030533-69c4ccadae00a',NULL,0,NULL,0,3000000,NULL),(297,3,'2026-03-26 03:05:49','Retirar en local','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260326030549-69c4ccbd219a7',NULL,4,'cash',0,3000000,'comprobante_20260326030549-69c4ccbd219a7.pdf'),(298,3,'2026-03-27 12:37:33','Pendiente de selección','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260327123733-69c6a43d37ab0',NULL,0,NULL,0,0,NULL),(299,3,'2026-03-27 12:37:49','Retirar en local','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260327123749-69c6a44de2fe3',NULL,4,'cash',0,400,'comprobante_20260327123749-69c6a44de2fe3.pdf'),(300,3,'2026-03-27 12:38:39','Retirar en local','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260327123839-69c6a47f36446',NULL,4,'cash',0,3000000,'comprobante_20260327123839-69c6a47f36446.pdf'),(301,3,'2026-03-27 12:39:05','Retirar en local','0','anto MACIEL<br>3624205620<br><br>camino san javier 2968<br>3500<br>resistencia<br>AR','20260327123905-69c6a499252bf',NULL,4,'cash',0,3000000,'comprobante_20260327123905-69c6a499252bf.pdf');
/*!40000 ALTER TABLE `order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order_details`
--

DROP TABLE IF EXISTS `order_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `order_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `binded_order_id` int(11) NOT NULL,
  `product` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `quantity` int(11) NOT NULL,
  `price` double NOT NULL,
  `total` double NOT NULL,
  `variants` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `product_object_id` int(11) DEFAULT NULL,
  `purchase_cost` double DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_845CA2C17C78A4E3` (`binded_order_id`),
  KEY `IDX_845CA2C14D8DE0A6` (`product_object_id`),
  CONSTRAINT `FK_845CA2C14D8DE0A6` FOREIGN KEY (`product_object_id`) REFERENCES `product` (`id`) ON DELETE SET NULL,
  CONSTRAINT `FK_845CA2C17C78A4E3` FOREIGN KEY (`binded_order_id`) REFERENCES `order` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=460 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_details`
--

LOCK TABLES `order_details` WRITE;
/*!40000 ALTER TABLE `order_details` DISABLE KEYS */;
INSERT INTO `order_details` VALUES (1,1,'Anillos Par',2,20000,40000,NULL,NULL,NULL),(2,1,'item',1,100,100,NULL,NULL,NULL),(3,1,'Collar + Aros',1,30000,30000,NULL,NULL,NULL),(4,2,'Anillos Par',3,20000,60000,NULL,NULL,NULL),(5,2,'item',1,100,100,NULL,NULL,NULL),(6,2,'Collar + Aros',1,30000,30000,NULL,NULL,NULL),(7,3,'Anillos Par',3,20000,60000,NULL,NULL,NULL),(8,3,'item',1,100,100,NULL,NULL,NULL),(9,3,'Collar + Aros',1,30000,30000,NULL,NULL,NULL),(10,4,'Anillos Par',3,20000,60000,NULL,NULL,NULL),(11,4,'item',1,100,100,NULL,NULL,NULL),(12,4,'Collar + Aros',1,30000,30000,NULL,NULL,NULL),(13,5,'Anillos Par',3,20000,60000,NULL,NULL,NULL),(14,5,'item',1,100,100,NULL,NULL,NULL),(15,5,'Collar + Aros',1,30000,30000,NULL,NULL,NULL),(16,6,'Anillos Par',3,20000,60000,NULL,NULL,NULL),(17,6,'item',1,100,100,NULL,NULL,NULL),(18,6,'Collar + Aros',1,30000,30000,NULL,NULL,NULL),(19,7,'Anillos Par',3,20000,60000,NULL,NULL,NULL),(20,7,'item',1,100,100,NULL,NULL,NULL),(21,7,'Collar + Aros',1,30000,30000,NULL,NULL,NULL),(22,8,'Anillos Par',3,20000,60000,NULL,NULL,NULL),(23,8,'item',1,100,100,NULL,NULL,NULL),(24,8,'Collar + Aros',1,30000,30000,NULL,NULL,NULL),(25,9,'Anillos Par',3,20000,60000,NULL,NULL,NULL),(26,9,'item',1,100,100,NULL,NULL,NULL),(27,9,'Collar + Aros',1,30000,30000,NULL,NULL,NULL),(28,10,'Anillos Par',3,20000,60000,NULL,NULL,NULL),(29,10,'item',1,100,100,NULL,NULL,NULL),(30,10,'Collar + Aros',1,30000,30000,NULL,NULL,NULL),(31,11,'Anillos Par',3,20000,60000,NULL,NULL,NULL),(32,11,'item',1,100,100,NULL,NULL,NULL),(33,11,'Collar + Aros',1,30000,30000,NULL,NULL,NULL),(34,12,'Anillos Par',3,20000,60000,NULL,NULL,NULL),(35,12,'item',1,100,100,NULL,NULL,NULL),(36,12,'Collar + Aros',1,30000,30000,NULL,NULL,NULL),(37,13,'Anillos Par',3,20000,60000,NULL,NULL,NULL),(38,13,'item',1,100,100,NULL,NULL,NULL),(39,13,'Collar + Aros',1,30000,30000,NULL,NULL,NULL),(40,14,'Anillos Par',3,20000,60000,NULL,NULL,NULL),(41,14,'item',1,100,100,NULL,NULL,NULL),(42,14,'Collar + Aros',1,30000,30000,NULL,NULL,NULL),(43,15,'Anillos Par',3,20000,60000,NULL,NULL,NULL),(44,15,'item',1,100,100,NULL,NULL,NULL),(45,15,'Collar + Aros',1,30000,30000,NULL,NULL,NULL),(46,16,'Anillos Par',4,20000,80000,NULL,NULL,NULL),(47,16,'item',1,100,100,NULL,NULL,NULL),(48,16,'Collar + Aros',1,30000,30000,NULL,NULL,NULL),(49,17,'Anillos Par',4,20000,80000,NULL,NULL,NULL),(50,17,'item',1,100,100,NULL,NULL,NULL),(51,17,'Collar + Aros',1,30000,30000,NULL,NULL,NULL),(52,18,'Anillos Par',2,20000,40000,NULL,NULL,NULL),(53,19,'Anillos Par',2,20000,40000,NULL,NULL,NULL),(54,19,'a',1,100,100,NULL,NULL,NULL),(55,20,'Anillos Par',1,20000,20000,NULL,NULL,NULL),(56,21,'Anillos Par',1,20000,20000,NULL,NULL,NULL),(57,22,'Anillos Par',1,20000,20000,NULL,NULL,NULL),(58,23,'Anillos Par',1,20000,20000,NULL,NULL,NULL),(59,24,'Anillos Par',1,20000,20000,NULL,NULL,NULL),(60,25,'Lampara Acordeon',2,1500000,3000000,'Talle: 16: plata',NULL,NULL),(61,25,'Lampara Acordeon',1,1500000,1500000,'Talle: 14: oro',NULL,NULL),(62,26,'Lampara Acordeon',6,1500000,9000000,'Talle: 16: plata',NULL,NULL),(63,26,'Lampara Acordeon',1,1500000,1500000,'Talle: 14: oro',NULL,NULL),(64,27,'lampara acordeon',6,20000,120000,'Talle: 16: plata',NULL,NULL),(65,27,'lampara acordeon',1,20000,20000,'Talle: 14: oro',NULL,NULL),(66,28,'lampara acordeon',6,20000,120000,'Talle: 16: plata',NULL,NULL),(67,28,'lampara acordeon',1,20000,20000,'Talle: 14: oro',NULL,NULL),(68,29,'lampara acordeon',6,20000,120000,'Talle: 16: plata',NULL,NULL),(69,29,'lampara acordeon',1,20000,20000,'Talle: 14: oro',NULL,NULL),(70,30,'lampara acordeon',6,20000,120000,'Talle: 16: plata',NULL,NULL),(71,30,'lampara acordeon',1,20000,20000,'Talle: 14: oro',NULL,NULL),(72,31,'lampara acordeon',6,20000,120000,'Talle: 16: plata',NULL,NULL),(73,31,'lampara acordeon',1,20000,20000,'Talle: 14: oro',NULL,NULL),(74,32,'lampara acordeon',6,20000,120000,'Talle: 16: plata',NULL,NULL),(75,32,'lampara acordeon',1,20000,20000,'Talle: 14: oro',NULL,NULL),(76,33,'lampara acordeon',6,20000,120000,'Talle: 16: plata',NULL,NULL),(77,33,'lampara acordeon',1,20000,20000,'Talle: 14: oro',NULL,NULL),(78,34,'lampara acordeon',1,20000,20000,'Talle: 16: plata',NULL,NULL),(79,35,'lampara acordeon',1,20000,20000,'Talle: 16: plata',NULL,NULL),(80,36,'lampara acordeon',1,20000,20000,'Talle: 16: plata',NULL,NULL),(81,37,'lampara acordeon',1,20000,20000,'Talle: 16: plata',NULL,NULL),(82,38,'lampara acordeon',1,20000,20000,'Talle: 16: plata',NULL,NULL),(83,39,'lampara acordeon',1,20000,20000,'Talle: 16: plata',NULL,NULL),(84,40,'lampara acordeon',1,20000,20000,'Talle: 16: plata',NULL,NULL),(85,41,'lampara acordeon',1,20000,20000,'Talle: 16: plata',NULL,NULL),(86,42,'lampara acordeon',1,20000,20000,'Talle: 16: plata',NULL,NULL),(87,43,'lampara acordeon',1,20000,20000,'Talle: 16: plata',NULL,NULL),(88,44,'lampara acordeon',1,20000,20000,'Talle: 16: plata',NULL,NULL),(89,45,'lampara acordeon',1,20000,20000,'Talle: 16: plata',NULL,NULL),(90,46,'lampara acordeon',1,20000,20000,'Talle: 16: plata',NULL,NULL),(91,47,'lampara acordeon',1,20000,20000,'Talle: 16: plata',NULL,NULL),(92,48,'lampara acordeon',1,20000,20000,'Talle: 16: plata',NULL,NULL),(93,49,'lampara acordeon',1,20000,20000,'Talle: 16: plata',NULL,NULL),(94,50,'lampara acordeon',1,20000,20000,'Talle: 16: plata',NULL,NULL),(95,51,'lampara acordeon',1,20000,20000,'Talle: 16: plata',NULL,NULL),(96,52,'lampara acordeon',1,20000,20000,'Talle: 16: plata',NULL,NULL),(97,53,'lampara acordeon',1,20000,20000,'Talle: 16: plata',NULL,NULL),(98,54,'lampara acordeon',1,20000,20000,'Talle: 16: plata',NULL,NULL),(99,55,'lampara acordeon',1,20000,20000,'Talle: 16: plata',NULL,NULL),(100,56,'lampara acordeon',1,20000,20000,'Talle: 16: plata',NULL,NULL),(101,57,'lampara acordeon',1,20000,20000,'Talle: 16: plata',NULL,NULL),(102,58,'lampara acordeon',1,20000,20000,'Talle: 16: plata',NULL,NULL),(103,59,'lampara acordeon',3,20000,60000,'Talle: 16: plata',NULL,NULL),(104,60,'lampara acordeon',3,20000,60000,'Talle: 16: plata',NULL,NULL),(105,61,'lampara acordeon',3,20000,60000,'Talle: 16: plata',NULL,NULL),(106,62,'lampara acordeon',3,20000,60000,'Talle: 16: plata',NULL,NULL),(107,63,'lampara acordeon',3,20000,60000,'Talle: 16: plata',NULL,NULL),(108,64,'lampara acordeon',8,20000,160000,'Talle: 16: plata',1,NULL),(109,65,'lampara acordeon',1,20000,20000,'Talle: 16: plata',1,NULL),(110,66,'lampara acordeon',1,20000,20000,'Talle: 16: plata',1,NULL),(111,67,'lampara acordeon',1,20000,20000,'Talle: 16: plata',1,NULL),(112,68,'lampara acordeon',1,20000,20000,'Talle: 16: plata',1,NULL),(113,69,'lampara acordeon',1,20000,20000,'Talle: 16: plata',1,NULL),(114,70,'lampara acordeon',1,20000,20000,'Talle: 16: plata',1,NULL),(115,71,'lampara acordeon',1,20000,20000,'Talle: 16: plata',1,NULL),(116,72,'lampara acordeon',1,20000,20000,'Talle: 16: plata',1,NULL),(117,73,'lampara acordeon',1,20000,20000,'Talle: 16: plata',1,NULL),(118,74,'lampara acordeon',1,20000,20000,'Talle: 16: plata',1,NULL),(119,75,'lampara acordeon',1,20000,20000,'Talle: 16: plata',1,NULL),(120,76,'lampara acordeon',1,20000,20000,'Talle: 16: plata',1,NULL),(121,77,'lampara acordeon',1,20000,20000,'Talle: 16: plata',1,NULL),(122,78,'lampara acordeon',1,20000,20000,'Talle: 16: plata',1,NULL),(123,79,'lampara acordeon',1,20000,20000,'Talle: 16: plata',1,NULL),(124,80,'lampara acordeon',1,20000,20000,'Talle: 16: plata',1,NULL),(125,81,'lampara acordeon',1,20000,20000,'Talle: 16: plata',1,NULL),(126,82,'lampara acordeon',1,20000,20000,'Talle: 16: plata',1,NULL),(127,83,'lampara acordeon',1,20000,20000,'Talle: 16: plata',1,NULL),(128,84,'lampara acordeon',1,20000,20000,'Talle: 16: plata',1,NULL),(129,85,'lampara acordeon',1,20000,20000,'Talle: 16: plata',1,NULL),(130,86,'lampara acordeon',1,20000,20000,'Talle: 16: plata',1,NULL),(131,87,'lampara acordeon',1,20000,20000,'Talle: 16: plata',1,NULL),(132,88,'lampara acordeon',1,20000,20000,'Talle: 16: plata',1,NULL),(133,89,'lampara acordeon',1,20000,20000,'Talle: 16: plata',1,NULL),(134,90,'lampara acordeon',1,20000,20000,'Talle: 16: plata',1,NULL),(135,91,'lampara acordeon',1,20000,20000,'Talle: 16: plata',1,NULL),(136,92,'lampara acordeon',1,20000,20000,'Talle: 16: plata',1,NULL),(137,93,'lampara acordeon',1,20000,20000,'Talle: 16: plata',1,NULL),(138,94,'lampara acordeon',1,20000,20000,'Talle: 16: plata',1,NULL),(139,95,'lampara acordeon',1,20000,20000,'Talle: 16: plata',1,NULL),(140,96,'lampara acordeon',1,20000,20000,'Talle: 16: plata',1,NULL),(141,97,'lampara acordeon',1,20000,20000,'Talle: 16: plata',1,NULL),(142,98,'lampara acordeon',1,20000,20000,'Talle: 16: plata',1,NULL),(143,99,'lampara acordeon',1,20000,20000,'Talle: 16: plata',1,NULL),(144,100,'lampara acordeon',1,20000,20000,'Talle: 16: plata',1,NULL),(145,101,'lampara acordeon',1,20000,20000,'Talle: 16: plata',1,NULL),(146,102,'lampara acordeon',1,20000,20000,'Talle: 16: plata',1,NULL),(147,103,'lampara acordeon',1,20000,20000,'Talle: 16: plata',1,NULL),(148,104,'lampara acordeon',1,20000,20000,'Talle: 16: plata',1,NULL),(149,105,'lampara acordeon',1,20000,20000,'Talle: 16: plata',1,NULL),(150,106,'lampara acordeon',1,20000,20000,'Talle: 16: plata',1,NULL),(151,107,'lampara acordeon',1,20000,20000,'Talle: 16: plata',1,NULL),(152,108,'lampara acordeon',1,20000,20000,'Talle: 16: plata',1,NULL),(153,109,'lampara acordeon',1,20000,20000,'Talle: 16: plata',1,NULL),(154,110,'lampara acordeon',1,20000,20000,'Talle: 16: plata',1,NULL),(155,111,'lampara acordeon',1,20000,20000,'Talle: 16: plata',1,NULL),(156,111,'lampara acordeon',1,20000,20000,'Talle: 14: oro',1,NULL),(157,112,'Anillo Compromiso',10,80000000,800000000,'Talle: 16: plata',1,NULL),(158,112,'Anillo Compromiso',2,80000000,160000000,'Talle: 14: oro',1,NULL),(159,112,'item',1,100,100,NULL,NULL,NULL),(160,112,'a',1,100,100,NULL,NULL,NULL),(161,113,'Anillo Compromiso',1,80000000,80000000,'Talle: 16: plata',1,NULL),(162,113,'Anillo Compromiso',1,80000000,80000000,'Talle: 14: oro',1,NULL),(163,113,'Pulseras de Oro',3,50000000,150000000,NULL,4,NULL),(164,114,'Anillo Compromiso',1,80000000,80000000,'Talle: 16: plata',1,NULL),(165,114,'Anillo Compromiso',1,80000000,80000000,'Talle: 14: oro',1,NULL),(166,114,'Pulseras de Oro',3,50000000,150000000,NULL,4,NULL),(167,115,'Anillo Compromiso',1,80000000,80000000,'Talle: 16: plata',1,NULL),(168,115,'Anillo Compromiso',1,80000000,80000000,'Talle: 14: oro',1,NULL),(169,115,'Pulseras de Oro',3,50000000,150000000,NULL,4,NULL),(170,116,'Anillo Compromiso',1,80000000,80000000,'Talle: 16: plata',1,NULL),(171,116,'Anillo Compromiso',1,80000000,80000000,'Talle: 14: oro',1,NULL),(172,116,'Pulseras de Oro',3,50000000,150000000,NULL,4,NULL),(173,117,'Anillo Compromiso',1,80000000,80000000,'Talle: 16: plata',1,NULL),(174,117,'Anillo Compromiso',1,80000000,80000000,'Talle: 14: oro',1,NULL),(175,117,'Pulseras de Oro',3,50000000,150000000,NULL,4,NULL),(176,118,'Anillo Compromiso',1,80000000,80000000,'Talle: 16: plata',1,NULL),(177,118,'Anillo Compromiso',1,80000000,80000000,'Talle: 14: oro',1,NULL),(178,118,'Pulseras de Oro',3,50000000,150000000,NULL,4,NULL),(179,119,'Anillo Compromiso',1,80000000,80000000,'Talle: 16: plata',1,NULL),(180,119,'Anillo Compromiso',1,80000000,80000000,'Talle: 14: oro',1,NULL),(181,119,'Pulseras de Oro',3,50000000,150000000,NULL,4,NULL),(182,120,'Pulseras de Oro',1,50000000,50000000,NULL,4,NULL),(183,121,'Pulseras de Oro',1,50000000,50000000,NULL,4,NULL),(184,122,'Collar + Aros',1,30000,30000,NULL,2,NULL),(185,123,'Collar + Aros',1,30000,30000,NULL,2,NULL),(186,124,'Collar + Aros',1,30000,30000,NULL,2,NULL),(187,125,'Collar + Aros',1,30000,30000,NULL,2,NULL),(188,126,'Collar + Aros',1,30000,30000,NULL,2,NULL),(189,127,'Collar + Aros',1,30000,30000,NULL,2,NULL),(190,128,'Collar + Aros',1,30000,30000,NULL,2,NULL),(191,129,'Collar + Aros',1,30000,30000,NULL,2,NULL),(192,130,'Collar + Aros',1,30000,30000,NULL,2,NULL),(193,131,'Collar + Aros',1,30000,30000,NULL,2,NULL),(194,132,'Collar + Aros',1,30000,30000,NULL,2,NULL),(195,133,'Collar + Aros',1,30000,30000,NULL,2,NULL),(196,133,'Anillo Compromiso',3,80000000,240000000,'Talle: 16: plata',1,NULL),(197,133,'Anillo Compromiso',1,80000000,80000000,'Talle: 16: plata, Talle: 14: oro',1,NULL),(198,134,'Pulseras de Oro',1,50000000,50000000,NULL,4,NULL),(199,134,'Anillo Compromiso',1,80000000,80000000,'Talle: 16: plata',1,NULL),(200,135,'Pulseras de Oro',1,50000000,50000000,NULL,4,NULL),(201,135,'Anillo Compromiso',1,80000000,80000000,'Talle: 16: plata',1,NULL),(202,136,'Pulseras de Oro',1,50000000,50000000,NULL,4,NULL),(203,136,'Anillo Compromiso',1,80000000,80000000,'Talle: 16: plata',1,NULL),(204,137,'Pulseras de Oro',1,50000000,50000000,NULL,4,NULL),(205,137,'Anillo Compromiso',1,80000000,80000000,'Talle: 16: plata',1,NULL),(206,138,'Pulseras de Oro',1,50000000,50000000,NULL,4,NULL),(207,138,'Anillo Compromiso',1,80000000,80000000,'Talle: 16: plata',1,NULL),(208,139,'Pulseras de Oro',1,50000000,50000000,NULL,4,NULL),(209,139,'Anillo Compromiso',1,80000000,80000000,'Talle: 16: plata',1,NULL),(210,140,'Pulseras de Oro',1,50000000,50000000,NULL,4,NULL),(211,140,'Anillo Compromiso',1,80000000,80000000,'Talle: 16: plata',1,NULL),(212,141,'Pulseras de Oro',1,50000000,50000000,NULL,4,NULL),(213,141,'Anillo Compromiso',1,80000000,80000000,'Talle: 16: plata',1,NULL),(214,142,'Pulseras de Oro',1,50000000,50000000,NULL,4,NULL),(215,142,'Anillo Compromiso',1,80000000,80000000,'Talle: 16: plata',1,NULL),(216,143,'Pulseras de Oro',1,50000000,50000000,NULL,4,NULL),(217,143,'Anillo Compromiso',1,80000000,80000000,'Talle: 16: plata',1,NULL),(218,144,'Pulseras de Oro',1,50000000,50000000,NULL,4,NULL),(219,144,'Anillo Compromiso',1,80000000,80000000,'Talle: 16: plata',1,NULL),(220,145,'Pulseras de Oro',1,50000000,50000000,NULL,4,NULL),(221,145,'Anillo Compromiso',1,80000000,80000000,'Talle: 16: plata',1,NULL),(222,146,'Pulseras de Oro',1,50000000,50000000,NULL,4,NULL),(223,146,'Anillo Compromiso',1,80000000,80000000,'Talle: 16: plata',1,NULL),(224,147,'Pulseras de Oro',1,50000000,50000000,NULL,4,NULL),(225,147,'Anillo Compromiso',1,80000000,80000000,'Talle: 16: plata',1,NULL),(226,148,'Pulseras de Oro',1,50000000,50000000,NULL,4,NULL),(227,148,'Anillo Compromiso',1,80000000,80000000,'Talle: 16: plata',1,NULL),(228,149,'Pulseras de Oro',1,50000000,50000000,NULL,4,NULL),(229,149,'Anillo Compromiso',1,80000000,80000000,'Talle: 16: plata',1,NULL),(230,150,'Pulseras de Oro',1,50000000,50000000,NULL,4,NULL),(231,150,'Anillo Compromiso',1,80000000,80000000,'Talle: 16: plata',1,NULL),(232,151,'Pulseras de Oro',1,50000000,50000000,NULL,4,NULL),(233,151,'Anillo Compromiso',1,80000000,80000000,'Talle: 16: plata',1,NULL),(234,152,'Pulseras de Oro',1,50000000,50000000,NULL,4,NULL),(235,152,'Anillo Compromiso',1,80000000,80000000,'Talle: 16: plata',1,NULL),(236,153,'Pulseras de Oro',1,50000000,50000000,NULL,4,NULL),(237,153,'Anillo Compromiso',1,80000000,80000000,'Talle: 16: plata',1,NULL),(238,154,'Pulseras de Oro',1,50000000,50000000,NULL,4,NULL),(239,154,'Anillo Compromiso',1,80000000,80000000,'Talle: 16: plata',1,NULL),(240,155,'Pulseras de Oro',1,50000000,50000000,NULL,4,NULL),(241,155,'Anillo Compromiso',1,80000000,80000000,'Talle: 16: plata',1,NULL),(242,156,'Pulseras de Oro',1,50000000,50000000,NULL,4,NULL),(243,156,'Anillo Compromiso',1,80000000,80000000,'Talle: 16: plata',1,NULL),(244,157,'Pulseras de Oro',1,50000000,50000000,NULL,4,NULL),(245,157,'Anillo Compromiso',1,80000000,80000000,'Talle: 16: plata',1,NULL),(246,158,'Pulseras de Oro',1,50000000,50000000,NULL,4,NULL),(247,158,'Anillo Compromiso',1,80000000,80000000,'Talle: 16: plata',1,NULL),(248,159,'Pulseras de Oro',1,50000000,50000000,NULL,4,NULL),(249,159,'Anillo Compromiso',1,80000000,80000000,'Talle: 16: plata',1,NULL),(250,160,'Pulseras de Oro',1,50000000,50000000,NULL,4,NULL),(251,160,'Anillo Compromiso',1,80000000,80000000,'Talle: 16: plata',1,NULL),(252,161,'Anillo Compromiso',1,80000000,80000000,'Talle: 16: plata',1,NULL),(253,162,'Anillo Compromiso',1,80000000,80000000,'Talle: 16: plata',1,NULL),(254,163,'Anillo Compromiso',1,80000000,80000000,'Talle: 16: plata',1,NULL),(255,164,'Anillo Compromiso',1,80000000,80000000,'Talle: 16: plata',1,NULL),(256,165,'Anillo Compromiso',1,80000000,80000000,'Talle: 16: plata',1,NULL),(257,166,'Anillo Compromiso',1,80000000,80000000,'Talle: 16: plata',1,NULL),(258,167,'Anillo Compromiso',1,80000000,80000000,'Talle: 16: plata',1,NULL),(259,168,'Anillo Compromiso',4,500000,2000000,'Talle: 16: plata',1,NULL),(260,169,'Pulseras de Oro',3,50000000,150000000,NULL,4,NULL),(261,169,'Anillo Compromiso Anillo Compromiso',1,500000,500000,'Talle: 14: oro',1,NULL),(262,170,'Anillo Compromiso Anillo Compromiso',1,500000,500000,'Talle: 16: plata',1,NULL),(263,171,'Anillo Compromiso Anillo Compromiso',1,500000,500000,'Talle: 16: plata',1,NULL),(264,172,'Anillo Compromiso Anillo Compromiso',1,500000,500000,'Talle: 16: plata',1,NULL),(265,173,'Anillo Compromiso Anillo Compromiso',1,500000,500000,'Talle: 16: plata',1,NULL),(266,174,'Anillo Compromiso Anillo Compromiso',1,500000,500000,'Talle: 16: plata',1,NULL),(267,175,'Anillo Compromiso Anillo Compromiso',1,500000,500000,'Talle: 16: plata',1,NULL),(268,176,'Anillo Compromiso Anillo Compromiso',1,500000,500000,'Talle: 16: plata',1,NULL),(269,177,'Anillo Compromiso Anillo Compromiso',1,500000,500000,'Talle: 16: plata',1,NULL),(270,178,'Anillo Compromiso Anillo Compromiso',1,500000,500000,'Talle: 16: plata',1,NULL),(271,179,'Anillo Compromiso Anillo Compromiso',1,500000,500000,'Talle: 16: plata',1,NULL),(272,179,'Pulseras de Oro',2,50000000,100000000,NULL,4,NULL),(273,180,'Anillo Compromiso Anillo Compromiso',9,500000,4500000,'Talle: 16: plata',1,NULL),(274,180,'item',1,100,100,NULL,8,NULL),(275,180,'Pantalon',1,20000,20000,NULL,14,NULL),(276,181,'Anillo Compromiso Anillo Compromiso',9,500000,4500000,'Talle: 16: plata',1,NULL),(277,181,'item',1,100,100,NULL,8,NULL),(278,181,'Pantalon',1,20000,20000,NULL,14,NULL),(279,182,'Anillo Compromiso Anillo Compromiso',9,500000,4500000,'Talle: 16: plata',1,NULL),(280,182,'item',1,100,100,NULL,8,NULL),(281,182,'Pantalon',1,20000,20000,NULL,14,NULL),(282,183,'Anillo Compromiso Anillo Compromiso',9,500000,4500000,'Talle: 16: plata',1,NULL),(283,183,'item',1,100,100,NULL,8,NULL),(284,183,'Pantalon',1,20000,20000,NULL,14,NULL),(285,184,'Anillo Compromiso Anillo Compromiso',9,500000,4500000,'Talle: 16: plata',1,NULL),(286,184,'item',1,100,100,NULL,8,NULL),(287,184,'Pantalon',1,20000,20000,NULL,14,NULL),(288,185,'Anillo Compromiso Anillo Compromiso',9,500000,4500000,'Talle: 16: plata',1,NULL),(289,185,'item',1,100,100,NULL,8,NULL),(290,185,'Pantalon',1,20000,20000,NULL,14,NULL),(291,186,'Anillo Compromiso Anillo Compromiso',9,500000,4500000,'Talle: 16: plata',1,NULL),(292,186,'item',1,100,100,NULL,8,NULL),(293,186,'Pantalon',1,20000,20000,NULL,14,NULL),(294,187,'Anillo Compromiso Anillo Compromiso',9,500000,4500000,'Talle: 16: plata',1,NULL),(295,187,'item',1,100,100,NULL,8,NULL),(296,187,'Pantalon',1,20000,20000,NULL,14,NULL),(297,188,'Anillo Compromiso Anillo Compromiso',9,500000,4500000,'Talle: 16: plata',1,NULL),(298,188,'item',1,100,100,NULL,8,NULL),(299,188,'Pantalon',1,20000,20000,NULL,14,NULL),(300,189,'Anillo Compromiso Anillo Compromiso',9,500000,4500000,'Talle: 16: plata',1,NULL),(301,189,'item',1,100,100,NULL,8,NULL),(302,189,'Pantalon',1,20000,20000,NULL,14,NULL),(303,190,'Anillo Compromiso Anillo Compromiso',9,500000,4500000,'Talle: 16: plata',1,NULL),(304,190,'item',1,100,100,NULL,8,NULL),(305,190,'Pantalon',1,20000,20000,NULL,14,NULL),(306,191,'Anillo Compromiso Anillo Compromiso',9,500000,4500000,'Talle: 16: plata',1,NULL),(307,191,'item',1,100,100,NULL,8,NULL),(308,191,'Pantalon',1,20000,20000,NULL,14,NULL),(309,192,'Anillo Compromiso Anillo Compromiso',9,500000,4500000,'Talle: 16: plata',1,NULL),(310,192,'item',1,100,100,NULL,8,NULL),(311,192,'Pantalon',1,20000,20000,NULL,14,NULL),(312,193,'Anillo Compromiso Anillo Compromiso',9,500000,4500000,'Talle: 16: plata',1,NULL),(313,193,'item',1,100,100,NULL,8,NULL),(314,193,'Pantalon',1,20000,20000,NULL,14,NULL),(315,194,'Anillo Compromiso Anillo Compromiso',9,500000,4500000,'Talle: 16: plata',1,NULL),(316,194,'item',1,100,100,NULL,8,NULL),(317,194,'Pantalon',1,20000,20000,NULL,14,NULL),(318,195,'Anillo Compromiso Anillo Compromiso',9,500000,4500000,'Talle: 16: plata',1,NULL),(319,195,'item',1,100,100,NULL,8,NULL),(320,195,'Pantalon',1,20000,20000,NULL,14,NULL),(321,196,'Anillo Compromiso Anillo Compromiso',9,500000,4500000,'Talle: 16: plata',1,NULL),(322,196,'item',1,100,100,NULL,8,NULL),(323,196,'Pantalon',1,20000,20000,NULL,14,NULL),(324,197,'Anillo Compromiso Anillo Compromiso',9,500000,4500000,'Talle: 16: plata',1,NULL),(325,197,'item',1,100,100,NULL,8,NULL),(326,197,'Pantalon',1,20000,20000,NULL,14,NULL),(327,198,'Anillo Compromiso Anillo Compromiso',9,500000,4500000,'Talle: 16: plata',1,NULL),(328,198,'item',1,100,100,NULL,8,NULL),(329,198,'Pantalon',1,20000,20000,NULL,14,NULL),(330,199,'Anillo Compromiso Anillo Compromiso',2,500000,1000000,'Talle: 16: plata',1,300000),(331,200,'Anillo Compromiso Anillo Compromiso',2,500000,1000000,'Talle: 16: plata',1,300000),(332,201,'Anillo Compromiso Anillo Compromiso',4,500000,2000000,'Talle: 16: plata',1,300000),(333,202,'Anillo Compromiso Anillo Compromiso',66,500000,33000000,'Talle: 16: plata',1,300000),(334,203,'Anillo Compromiso Anillo Compromiso',1,500000,500000,'Talle: 16: plata',1,300000),(335,204,'Pulseras de Oro',1,50000000,50000000,NULL,4,NULL),(336,205,'item',1,100,100,NULL,8,NULL),(337,206,'Anillo Compromiso Anillo Compromiso',1,500000,500000,'Talle: 16: plata',1,300000),(338,207,'item',1,100,100,NULL,7,NULL),(339,208,'colarres colaff',1,100,100,NULL,9,NULL),(340,209,'Anillo Compromiso Anillo Compromiso',1,500000,500000,'Talle: 16: plata',1,300000),(341,210,'colarres colaff',1,100,100,NULL,9,NULL),(342,211,'colarres colaff',1,100,100,NULL,9,NULL),(343,212,'Anillo Compromiso Anillo Compromiso',1,500000,500000,'Talle: 16: plata',1,300000),(344,213,'Anillo Compromiso Anillo Compromiso',1,500000,500000,'Talle: 16: plata',1,300000),(345,214,'camisa',1,10000,10000,NULL,15,NULL),(346,214,'Combo Accesorios',1,60000,60000,NULL,3,NULL),(347,214,'Collar + Aros',1,30000,30000,NULL,2,NULL),(348,214,'producto',1,10000,10000,NULL,16,NULL),(349,214,'producto 1',1,40000,40000,NULL,17,NULL),(350,215,'producto',1,10000,10000,NULL,16,NULL),(351,215,'producto 1',1,40000,40000,NULL,17,NULL),(352,215,'camisa',1,10000,10000,NULL,15,NULL),(353,215,'hair brush',1,300000,300000,NULL,9,NULL),(354,215,'bikinis',1,800000,800000,NULL,14,NULL),(355,215,'Texanas',1,3000000,3000000,NULL,4,NULL),(356,216,'Texanas',5,3000000,15000000,NULL,4,NULL),(357,216,'hair brush',1,300000,300000,NULL,9,NULL),(358,217,'Short de jean PINK',3,1200000,3600000,'Talle: 16: plata',1,300000),(359,218,'Short de jean PINK',3,1200000,3600000,'Talle: 16: plata',1,300000),(360,219,'Short de jean PINK',3,1200000,3600000,'Talle: 16: plata',1,300000),(361,220,'Short de jean PINK',3,1200000,3600000,'Talle: 16: plata',1,300000),(362,221,'Texanas',1,3000000,3000000,NULL,4,NULL),(363,222,'Texanas',1,3000000,3000000,NULL,4,NULL),(364,223,'hair brush',1,300000,300000,NULL,9,NULL),(365,224,'hair brush',1,300000,300000,NULL,9,NULL),(366,225,'hair brush',1,300000,300000,NULL,9,NULL),(367,226,'bikinis',1,800000,800000,NULL,14,NULL),(368,227,'Texanas',1,3000000,3000000,NULL,4,NULL),(369,228,'Texanas',11,3000000,33000000,NULL,4,NULL),(370,229,'Texanas',11,3000000,33000000,NULL,4,NULL),(371,230,'Texanas',11,3000000,33000000,NULL,4,NULL),(372,231,'Texanas',11,3000000,33000000,NULL,4,NULL),(373,232,'Texanas',11,3000000,33000000,NULL,4,NULL),(374,233,'Texanas',1,3000000,3000000,NULL,4,NULL),(375,234,'Texanas',1,3000000,3000000,NULL,4,NULL),(376,235,'Texanas',1,3000000,3000000,NULL,4,NULL),(377,236,'Texanas',1,3000000,3000000,NULL,4,NULL),(378,237,'Texanas',1,3000000,3000000,NULL,4,NULL),(379,238,'hair brush',1,300000,300000,NULL,9,NULL),(380,238,'Texanas',1,3000000,3000000,NULL,4,NULL),(381,239,'Texanas',1,3000000,3000000,NULL,4,NULL),(382,240,'Texanas',1,3000000,3000000,NULL,4,NULL),(383,241,'hair brush',1,300000,300000,NULL,9,NULL),(384,242,'Short de jean PINK',1,1200000,1200000,'Talle: 16: plata',1,300000),(385,243,'hair brush',1,300000,300000,NULL,9,NULL),(386,244,'hair brush',1,300000,300000,NULL,9,NULL),(387,245,'hair brush',1,300000,300000,NULL,9,NULL),(388,246,'hair brush',1,300000,300000,NULL,9,NULL),(389,247,'hair brush',1,300000,300000,NULL,9,NULL),(390,248,'hair brush',1,300000,300000,NULL,9,NULL),(391,249,'hair brush',1,300000,300000,NULL,9,NULL),(392,250,'hair brush',1,300000,300000,NULL,9,NULL),(393,251,'hair brush',1,300000,300000,NULL,9,NULL),(394,252,'hair brush',1,300000,300000,NULL,9,NULL),(395,253,'hair brush',1,300000,300000,NULL,9,NULL),(396,254,'hair brush',1,300000,300000,NULL,9,NULL),(397,255,'hair brush',1,300000,300000,NULL,9,NULL),(398,256,'hair brush',1,300000,300000,NULL,9,NULL),(399,257,'hair brush',1,300000,300000,NULL,9,NULL),(400,258,'hair brush',1,300000,300000,NULL,9,NULL),(401,259,'hair brush',1,300000,300000,NULL,9,NULL),(402,260,'hair brush',1,300000,300000,NULL,9,NULL),(403,261,'hair brush',1,300000,300000,NULL,9,NULL),(404,262,'hair brush',1,300000,300000,NULL,9,NULL),(405,263,'hair brush',1,300000,300000,NULL,9,NULL),(406,264,'hair brush',1,300000,300000,NULL,9,NULL),(407,265,'hair brush',1,300000,300000,NULL,9,NULL),(408,266,'hair brush',1,300000,300000,NULL,9,NULL),(409,267,'Texanas',1,3000000,3000000,NULL,4,NULL),(410,268,'hair brush',1,300000,300000,NULL,9,NULL),(411,269,'bikinis',1,800000,800000,NULL,14,NULL),(412,270,'hair brush',1,300000,300000,NULL,9,NULL),(413,271,'hair brush',3,300000,900000,NULL,9,NULL),(414,272,'hair brush',3,300000,900000,NULL,9,NULL),(415,273,'hair brush',3,300000,900000,NULL,9,NULL),(416,274,'bikinis',2,800000,1600000,NULL,14,NULL),(417,275,'Texanas',1,3000000,3000000,NULL,4,NULL),(418,275,'Short de jean PINK',2,1200000,2400000,'Talle: 16: plata',1,300000),(419,276,'Short de jean PINK',1,1200000,1200000,'Talle: 16: plata',1,300000),(420,277,'Texanas',2,3000000,6000000,NULL,4,NULL),(421,277,'Short de jean PINK',1,1200000,1200000,'Talle: 16: plata',1,300000),(422,278,'Short de jean PINK',1,1200000,1200000,'Talle: 16: plata',1,300000),(423,279,'Texanas',2,3000000,6000000,NULL,4,NULL),(424,279,'Short de jean PINK',3,1200000,3600000,'Talle: 16: plata',1,300000),(425,280,'Texanas',2,3000000,6000000,NULL,4,NULL),(426,280,'Short de jean PINK',3,1200000,3600000,'Talle: 16: plata',1,300000),(427,281,'Texanas',2,3000000,6000000,NULL,4,NULL),(428,281,'Short de jean PINK',3,1200000,3600000,'Talle: 16: plata',1,300000),(429,282,'Texanas',2,3000000,6000000,NULL,4,NULL),(430,282,'Short de jean PINK',3,1200000,3600000,'Talle: 16: plata',1,300000),(431,283,'Texanas',2,3000000,6000000,NULL,4,NULL),(432,283,'Short de jean PINK',3,1200000,3600000,'Talle: 16: plata',1,300000),(433,284,'Texanas',2,3000000,6000000,NULL,4,NULL),(434,284,'Short de jean PINK',3,1200000,3600000,'Talle: 16: plata',1,300000),(435,285,'Texanas',2,3000000,6000000,NULL,4,NULL),(436,285,'Short de jean PINK',3,1200000,3600000,'Talle: 16: plata',1,300000),(437,286,'Texanas',2,3000000,6000000,NULL,4,NULL),(438,286,'Short de jean PINK',3,1200000,3600000,'Talle: 16: plata',1,300000),(439,287,'Texanas',2,3000000,6000000,NULL,4,NULL),(440,287,'Short de jean PINK',3,1200000,3600000,'Talle: 16: plata',1,300000),(441,288,'Texanas',2,3000000,6000000,NULL,4,NULL),(442,288,'Short de jean PINK',3,1200000,3600000,'Talle: 16: plata',1,300000),(443,289,'Texanas',3,3000000,9000000,NULL,4,NULL),(444,289,'Short de jean PINK',4,1200000,4800000,'Talle: 16: plata',1,300000),(445,289,'producto',1,10000,10000,NULL,16,NULL),(446,290,'Texanas',3,3000000,9000000,NULL,4,NULL),(447,290,'Short de jean PINK',4,1200000,4800000,'Talle: 16: plata',1,300000),(448,290,'producto',1,10000,10000,NULL,16,NULL),(449,291,'Combo Accesorios',1,60000,60000,NULL,3,NULL),(450,292,'Texanas',1,3000000,3000000,NULL,4,NULL),(451,293,'Texanas',1,3000000,3000000,NULL,4,NULL),(452,294,'hair brush',1,300000,300000,NULL,9,NULL),(453,295,'hair brush',1,300000,300000,NULL,9,NULL),(454,296,'Texanas',1,3000000,3000000,NULL,4,NULL),(455,297,'Texanas',1,3000000,3000000,NULL,4,NULL),(456,298,'item',4,100,400,NULL,8,NULL),(457,299,'item',4,100,400,NULL,8,NULL),(458,300,'Texanas',1,3000000,3000000,NULL,4,NULL),(459,301,'Texanas',1,3000000,3000000,NULL,4,NULL);
/*!40000 ALTER TABLE `order_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `personalize`
--

DROP TABLE IF EXISTS `personalize`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `personalize` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `logo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `primarycolor` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `secondarycolor` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tertiary_color` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `company_name` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `whatsapp` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `instagram` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `twitter` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `linkedin` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tiktok` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `youtube` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `province` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `city` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `alias_cbu` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `postal` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `personalize`
--

LOCK TABLES `personalize` WRITE;
/*!40000 ALTER TABLE `personalize` DISABLE KEYS */;
INSERT INTO `personalize` VALUES (1,'e63f927f35bbbf7d201e51a05b97ad0d07dbc43b.bin','#ffb3ec','#fdb4fe','#ea2a86','BENDITAS','antonelamaciel2024@gmail.com','+5493624205620','https://www.instagram.com',NULL,NULL,NULL,NULL,'Chaco','Resistencia','Santa Maria de Oro 156','benditas.ropa','3500');
/*!40000 ALTER TABLE `personalize` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product`
--

DROP TABLE IF EXISTS `product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `subtitle` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` longtext COLLATE utf8mb4_unicode_ci,
  `price` double NOT NULL,
  `is_in_home` tinyint(1) NOT NULL,
  `images` json DEFAULT NULL,
  `old_price` double DEFAULT NULL,
  `stock` int(11) DEFAULT NULL,
  `purchase_cost` double DEFAULT NULL,
  `purchase_date` datetime DEFAULT NULL,
  `supplier_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_D34A04AD12469DE2` (`category_id`),
  KEY `IDX_D34A04AD2ADD6D8C` (`supplier_id`),
  CONSTRAINT `FK_D34A04AD12469DE2` FOREIGN KEY (`category_id`) REFERENCES `category` (`id`),
  CONSTRAINT `FK_D34A04AD2ADD6D8C` FOREIGN KEY (`supplier_id`) REFERENCES `supplier` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product`
--

LOCK TABLES `product` WRITE;
/*!40000 ALTER TABLE `product` DISABLE KEYS */;
INSERT INTO `product` VALUES (1,2,'Short de jean PINK','acordeon','cccffbe9e9d4ab889f2392e389fbf9318ddb5a6b.png','Anillo de compromiso con caja de regalo.','Lampara acordeon luz calida ideal para mesas de noche! no te quedes sin la tuya',1200000,1,'[\"ab1a374e75537b368ac380c4c430167c5af42863.jpg\", \"1323f6f0d79f8f9ff97d.png\", \"5b0206929cf87b2bf239.png\", \"b09bcfc6d68e84480333.png\"]',2000000,83,300000,'2026-03-19 01:13:00',1),(2,2,'Collar + Aros','collar-aros','495bac395e39388982d7158ab4797234d0d39499.jpg','Collar y Par de Aros','Collar y par de aros en oro 18k conjunto ideal para uso diario.',30000,0,'[\"66e30fb652ec12a2c3e2.png\", \"ff34f23e4794d983e9ec.png\", \"bc4e68454e0ff3d98ada.png\", \"9aef8f8c99427a7f514a.png\", \"37b178d20d1f521f6345.png\", \"fc5773921ce2f6208f84.png\", \"1c2a3167dbfc9c5ae674.png\", \"7b2f8142edb9f65a7d19.png\"]',NULL,2,NULL,NULL,NULL),(3,4,'Combo Accesorios','combo-accesorios','9806e0c3a1728da091180e4b09c9ee906d10c323.jpg','Combo de accesorios completo','Combo accesorios collar + aros + anillos combo completo! ideal para regalo.',60000,0,'[\"8aec83bea4fa381e997f.png\", \"49e6434fa8834eebcefd.png\", \"e208e050d9da20972d9d.png\"]',NULL,NULL,NULL,NULL,NULL),(4,1,'Texanas','item','a7527d7ade1531e3a9248a45bb28fa908678f395.png','Botas texanas temporada otono 2026','Botas texanas del 34 al 42 ideal para esta temporada!',3000000,1,'[]',NULL,NULL,NULL,NULL,NULL),(7,1,'item','item1111','164d1d61041f81ed089ea2f9d109d8c0c651b7cb.jpg','item','item',100,0,'[]',NULL,NULL,NULL,NULL,NULL),(8,1,'item','item2222','de43ff029deaffa67b35d32603257a996cd97074.jpg','item','item',100,0,'[]',NULL,NULL,NULL,NULL,NULL),(9,1,'hair brush','item333','5802dfa6f93db2b0fdbc8f44ae33b84e13dd820d.png','item','item',300000,1,'[]',NULL,NULL,NULL,NULL,NULL),(14,1,'bikinis','pantalon','eb65a4cf54bc591a9a4eb87d58fec051258b73e7.png','ni ideae','ni idea',800000,1,'[]',NULL,NULL,NULL,NULL,NULL),(15,1,'camisa','camisa-f7f10a',NULL,NULL,NULL,10000,0,'[]',NULL,NULL,NULL,NULL,NULL),(16,1,'producto','producto-ad75fa','32ef7389665997706882300c7ce7b33eee95d788.png',NULL,NULL,10000,0,'[]',NULL,NULL,NULL,NULL,NULL),(17,1,'producto 1','producto-1-bcffc8','3ac3a5d436ce94d9b31b756de573c8a999904230.bin',NULL,NULL,40000,0,'[]',NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `product` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_option`
--

DROP TABLE IF EXISTS `product_option`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product_option` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_available` tinyint(1) NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `stock` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_38FA41144584665A` (`product_id`),
  CONSTRAINT `FK_38FA41144584665A` FOREIGN KEY (`product_id`) REFERENCES `product` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_option`
--

LOCK TABLES `product_option` WRITE;
/*!40000 ALTER TABLE `product_option` DISABLE KEYS */;
INSERT INTO `product_option` VALUES (1,1,'Talle: 16',1,'547309804a271f8075ec8a9cf03491073880f7c3.jpg',NULL),(2,1,'Talle: 14',1,NULL,NULL),(3,1,'Talle: 10',1,'1e207c189be166951a18a589e417661a3ad644bd.jpg',NULL),(4,14,'Rojo',0,NULL,NULL);
/*!40000 ALTER TABLE `product_option` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_option_value`
--

DROP TABLE IF EXISTS `product_option_value`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product_option_value` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_option_id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_available` tinyint(1) NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `stock` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_A938C737C964ABE2` (`product_option_id`),
  CONSTRAINT `FK_A938C737C964ABE2` FOREIGN KEY (`product_option_id`) REFERENCES `product_option` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_option_value`
--

LOCK TABLES `product_option_value` WRITE;
/*!40000 ALTER TABLE `product_option_value` DISABLE KEYS */;
INSERT INTO `product_option_value` VALUES (1,1,'oro',0,NULL,NULL),(2,1,'plata',1,'ab1a374e75537b368ac380c4c430167c5af42863.jpg',NULL),(3,2,'oro',1,NULL,NULL),(4,2,'plata',0,NULL,NULL);
/*!40000 ALTER TABLE `product_option_value` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_subcategory`
--

DROP TABLE IF EXISTS `product_subcategory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product_subcategory` (
  `product_id` int(11) NOT NULL,
  `subcategory_id` int(11) NOT NULL,
  PRIMARY KEY (`product_id`,`subcategory_id`),
  KEY `IDX_A1F33A574584665A` (`product_id`),
  KEY `IDX_A1F33A575DC6FE57` (`subcategory_id`),
  CONSTRAINT `FK_A1F33A574584665A` FOREIGN KEY (`product_id`) REFERENCES `product` (`id`) ON DELETE CASCADE,
  CONSTRAINT `FK_A1F33A575DC6FE57` FOREIGN KEY (`subcategory_id`) REFERENCES `subcategory` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_subcategory`
--

LOCK TABLES `product_subcategory` WRITE;
/*!40000 ALTER TABLE `product_subcategory` DISABLE KEYS */;
INSERT INTO `product_subcategory` VALUES (1,1),(1,2),(1,3);
/*!40000 ALTER TABLE `product_subcategory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shipping_return`
--

DROP TABLE IF EXISTS `shipping_return`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shipping_return` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `icon` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_published` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shipping_return`
--

LOCK TABLES `shipping_return` WRITE;
/*!40000 ALTER TABLE `shipping_return` DISABLE KEYS */;
INSERT INTO `shipping_return` VALUES (1,'Envios','<blockquote><h1><strong>aqui tendras&nbsp;</strong></h1></blockquote><div>toda la informacion sobre envios!</div><ul><li>1</li><li>2</li><li>3</li></ul>','bi-truck',1),(3,'jdjdjdj','<div>cjcdjdjd</div>',NULL,0);
/*!40000 ALTER TABLE `shipping_return` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subcategory`
--

DROP TABLE IF EXISTS `subcategory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `subcategory` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_DDCA44812469DE2` (`category_id`),
  CONSTRAINT `FK_DDCA44812469DE2` FOREIGN KEY (`category_id`) REFERENCES `category` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subcategory`
--

LOCK TABLES `subcategory` WRITE;
/*!40000 ALTER TABLE `subcategory` DISABLE KEYS */;
INSERT INTO `subcategory` VALUES (1,2,'oro'),(2,2,'plata'),(3,2,'aleacion'),(4,2,'acero'),(5,4,'Anillos compromiso'),(6,4,'Anillo + Collar'),(8,2,'1'),(9,2,'2'),(10,2,'3'),(11,2,'4'),(12,2,'5'),(13,2,'6');
/*!40000 ALTER TABLE `subcategory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `supplier`
--

DROP TABLE IF EXISTS `supplier`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `supplier` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `supplier`
--

LOCK TABLES `supplier` WRITE;
/*!40000 ALTER TABLE `supplier` DISABLE KEYS */;
INSERT INTO `supplier` VALUES (1,'proveedor 1');
/*!40000 ALTER TABLE `supplier` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(180) COLLATE utf8mb4_unicode_ci NOT NULL,
  `roles` json NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `firstname` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lastname` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_8D93D649E7927C74` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,'ejemplo@gmail.com','[]','$2y$13$dOY61SInK4DWhwGC1itdnebRY347vrQplRNNBoOQqvUy..kA/eZU6','anto','maciel'),(2,'mail@mail.com','[\"ROLE_USER\", \"ROLE_ADMIN\"]','$2y$13$OwMZViZp8xodr0NfjAznze31d.jzq4H0OOzn.FqxqSsdoA1obSA1K','ejem','ejem'),(3,'admin@admin.com','[\"ROLE_USER\", \"ROLE_ADMIN\"]','$2y$13$XNPieBeS8bOeIGNGS1qyBe2FPlJnkVXCdwOebR0auzr0rlPy0JsIK','anto','maciel'),(4,'presencial@example.com','[]','dummy_hash','Presencial','');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-03-27 19:59:31
